"""
signals.py - researched forex signals for your Discord bot (discord.py 2.x)

/signal pair [risk]   -> BUY / SELL / NO TRADE, when to enter, where to exit, how long to hold
/setbalance amount    -> optional: saves your balance so /signal can also show a lot size

main.py calls register(tree) for you before the bot starts.
Install: pip install discord.py openai yfinance feedparser aiohttp pandas
"""
import asyncio
import itertools
import json
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from typing import Optional
from urllib.parse import quote_plus

import aiohttp
import discord
import feedparser
import pandas as pd
import yfinance as yf
from discord import app_commands
from openai import AsyncOpenAI

# ----------------------------------------------------------------- settings
CURRENCIES = {"USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD", "ZAR", "MXN",
              "SEK", "NOK", "SGD", "HKD", "TRY", "PLN", "CNH"}
ALIASES = {"GOLD": "XAUUSD", "XAU": "XAUUSD", "SILVER": "XAGUSD", "XAG": "XAGUSD",
           "EURO": "EURUSD", "POUND": "GBPUSD", "CABLE": "GBPUSD", "YEN": "USDJPY",
           "RAND": "USDZAR", "AUSSIE": "AUDUSD", "KIWI": "NZDUSD", "LOONIE": "USDCAD", "SWISSIE": "USDCHF"}
SPECIAL_SYMBOLS = {"XAUUSD": "GC=F", "XAGUSD": "SI=F"}
POPULAR = ["EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "NZDUSD", "USDCAD", "EURGBP",
           "EURJPY", "GBPJPY", "AUDJPY", "USDZAR", "XAUUSD", "XAGUSD"]
CENTRAL_BANK = {"USD": "Federal Reserve", "EUR": "ECB", "GBP": "Bank of England", "JPY": "Bank of Japan",
                "AUD": "RBA", "NZD": "RBNZ", "CAD": "Bank of Canada", "CHF": "SNB", "ZAR": "SARB"}

# risk_pct = % of balance risked (only used if you saved a balance), min_conf = AI confidence needed,
# sl_atr = stop distance in ATRs, rr = reward:risk
RISK_PROFILES = {
    "low":    {"risk_pct": 0.5, "min_conf": 75, "sl_atr": 2.0, "rr": 2.0},
    "medium": {"risk_pct": 1.0, "min_conf": 65, "sl_atr": 1.5, "rr": 2.0},
    "high":   {"risk_pct": 3.0, "min_conf": 55, "sl_atr": 1.2, "rr": 2.0},
}

NEWS_FEEDS = ["https://www.fxstreet.com/rss/news", "https://www.forexlive.com/feed"]
CALENDAR_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"  # free, no key
BALANCE_FILE = "balances.json"
SAST = timezone(timedelta(hours=2))  # Eswatini time

NVIDIA_MODEL = os.getenv("NVIDIA_MODEL", "")  # optional: force one model
MODEL_CANDIDATES: list = []  # filled by main.py from your models.yaml (tried in order)
_keys = [k.strip() for k in os.getenv("NVIDIA_API_KEYS", os.getenv("NVIDIA_API_KEY", "")).split(",") if k.strip()]
_key_cycle = itertools.cycle(_keys) if _keys else None
HEADERS = {"User-Agent": "Mozilla/5.0 (forex-bot)"}
LLM_TIMEOUT_S = 40      # max wait for one AI model
LLM_PARALLEL = 3        # ask this many models at once and use the fastest valid answer
FETCH_TIMEOUT_S = 15    # max wait for each news/calendar/web source
PRICE_TIMEOUT_S = 25    # max wait for price data
TOTAL_TIMEOUT_S = 110   # hard limit for the whole command


# ----------------------------------------------------------------- small helpers
def clip(text, n=1000) -> str:
    text = str(text) if text is not None else "-"
    text = text.strip() or "-"
    return text if len(text) <= n else text[: n - 1] + "…"


def to_int(x, default=0) -> int:
    try:
        return int(float(str(x).replace("%", "").strip()))
    except Exception:
        return default


def local(dt: datetime) -> str:
    return dt.astimezone(SAST).strftime("%a %H:%M")


def parse_pair(text: str) -> Optional[str]:
    """'eur/usd', 'EUR USD', 'gold' -> 'EURUSD'. Returns None if it isn't a real pair."""
    t = re.sub(r"[^A-Za-z]", "", text or "").upper()
    t = ALIASES.get(t, t)
    if t in SPECIAL_SYMBOLS:
        return t
    if len(t) == 6 and t[:3] in CURRENCIES and t[3:] in CURRENCIES and t[:3] != t[3:]:
        return t
    return None


def decimals(pair: str) -> int:
    if "JPY" in pair:
        return 3
    return 2 if pair.startswith("XA") else 5


def load_balances() -> dict:
    try:
        with open(BALANCE_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_balance(user_id: int, amount: float):
    data = load_balances()
    data[str(user_id)] = amount
    with open(BALANCE_FILE, "w") as f:
        json.dump(data, f)


# ----------------------------------------------------------------- market / sessions
def market_open(now: datetime) -> bool:
    wd, h = now.weekday(), now.hour  # Mon=0 ... Sun=6 (UTC)
    if wd == 5 or (wd == 4 and h >= 21) or (wd == 6 and h < 21):
        return False
    return True


def session_info(pair: str, now: datetime) -> dict:
    h = now.hour
    active = []
    if h >= 22 or h < 7:
        active.append("Sydney")
    if 0 <= h < 9:
        active.append("Tokyo")
    if 7 <= h < 16:
        active.append("London")
    if 12 <= h < 21:
        active.append("New York")
    quality, note = 1, "Quiet/off-peak hours - thin liquidity and random moves."
    if "London" in active and "New York" in active:
        quality, note = 3, "London/New York overlap - the most liquid, best time to trade."
    elif "London" in active or "New York" in active:
        quality, note = 2, "Major session open - decent liquidity."
    prefs = {"JPY": "Tokyo", "AUD": "Sydney", "NZD": "Sydney", "EUR": "London", "GBP": "London",
             "CHF": "London", "USD": "New York", "CAD": "New York", "XAU": "New York", "XAG": "New York"}
    home = {prefs[c] for c in (pair[:3], pair[3:]) if c in prefs}
    matches = bool(home & set(active))
    if quality == 1 and matches:
        quality, note = 2, "Quiet overall, but one of this pair's home sessions is open."
    return {"active": active or ["No major session"], "quality": quality, "note": note, "pair_session_match": matches}


def next_good_window(pair: str, now: datetime) -> datetime:
    """Start of the next busy period for this pair (UTC)."""
    cur = {pair[:3], pair[3:]}
    if cur & {"JPY", "AUD", "NZD"} and not cur & {"EUR", "GBP", "CHF", "USD", "CAD"}:
        hour = 0   # Tokyo open
    elif cur & {"EUR", "GBP", "CHF"} and "USD" not in cur:
        hour = 7   # London open
    else:
        hour = 12  # London/New York overlap
    cand = now.replace(hour=hour, minute=0, second=0, microsecond=0)
    if cand <= now:
        cand += timedelta(days=1)
    while cand.weekday() >= 5:
        cand += timedelta(days=1)
    return cand


def friday_close(now: datetime) -> datetime:
    days = (4 - now.weekday()) % 7
    t = (now + timedelta(days=days)).replace(hour=20, minute=0, second=0, microsecond=0)
    return t if t > now else t + timedelta(days=7)


# ----------------------------------------------------------------- research (news, calendar, web)
async def fetch_bytes(session: aiohttp.ClientSession, url: str) -> bytes:
    async with session.get(url, headers=HEADERS, timeout=aiohttp.ClientTimeout(total=12)) as r:
        return await r.read()


def parse_news_feed(feed, limit=6, now=None) -> list[dict]:
    now = now or datetime.now(timezone.utc)
    out = []
    for e in feed.entries[: limit * 2]:
        title, source = e.get("title", ""), ""
        if " - " in title:
            title, source = title.rsplit(" - ", 1)
        age = None
        if e.get("published_parsed"):
            pub = datetime(*e.published_parsed[:6], tzinfo=timezone.utc)
            age = max(0, round((now - pub).total_seconds() / 3600))
        if title.strip():
            out.append({"title": title.strip(), "source": source.strip(), "age_hours": age})
    return out[:limit]


async def web_research(pair: str) -> list[dict]:
    """Searches Google News for fresh analysis/forecasts about this pair and its central banks."""
    base, quote = pair[:3], pair[3:]
    if pair in ("XAUUSD", "XAGUSD"):
        metal = "gold" if pair == "XAUUSD" else "silver"
        queries = [f"{metal} price forecast", f"{metal} price outlook this week", "Federal Reserve rate expectations dollar"]
    else:
        queries = [f"{base}/{quote} forecast", f"{base} {quote} outlook this week"]
        for c in (base, quote):
            if c in CENTRAL_BANK:
                queries.append(f"{CENTRAL_BANK[c]} interest rate outlook")
    urls = ["https://news.google.com/rss/search?q=" + quote_plus(q + " when:3d") + "&hl=en-US&gl=US&ceid=US:en"
            for q in queries[:4]]
    items, seen = [], set()
    try:
        async with aiohttp.ClientSession() as s:
            raws = await asyncio.gather(*(fetch_bytes(s, u) for u in urls), return_exceptions=True)
        for raw in raws:
            if isinstance(raw, Exception):
                continue
            for it in parse_news_feed(feedparser.parse(raw), limit=5):
                key = it["title"].lower()[:60]
                if key not in seen:
                    seen.add(key)
                    items.append(it)
    except Exception as ex:
        print("web research error:", ex)
    items.sort(key=lambda x: (x["age_hours"] is None, x["age_hours"] or 0))
    return items[:12]


async def fetch_headlines(limit=6) -> list[str]:
    heads = []
    try:
        async with aiohttp.ClientSession() as s:
            raws = await asyncio.gather(*(fetch_bytes(s, u) for u in NEWS_FEEDS), return_exceptions=True)
        for raw in raws:
            if not isinstance(raw, Exception):
                heads += [e.title for e in feedparser.parse(raw).entries[:limit]]
    except Exception as ex:
        print("headline error:", ex)
    return heads[: limit * 2]


async def fetch_calendar(pair: str, now: datetime) -> list[dict]:
    currencies = {"USD"} if pair in ("XAUUSD", "XAGUSD") else {pair[:3], pair[3:]}
    events = []
    try:
        async with aiohttp.ClientSession() as s:
            raw = await fetch_bytes(s, CALENDAR_URL)
        for e in json.loads(raw):
            if e.get("country") not in currencies or e.get("impact") not in ("High", "Medium"):
                continue
            when = datetime.fromisoformat(e["date"]).astimezone(timezone.utc)
            delta = (when - now).total_seconds() / 60
            if -120 <= delta <= 7 * 24 * 60:
                events.append({"title": e["title"], "currency": e["country"], "impact": e["impact"],
                               "minutes_from_now": round(delta), "forecast": e.get("forecast"),
                               "previous": e.get("previous"), "when": when})
    except Exception as ex:
        print("calendar error:", ex)
    return sorted(events, key=lambda x: x["minutes_from_now"])


# ----------------------------------------------------------------- technicals
def ema(s, n): return s.ewm(span=n, adjust=False).mean()


def rsi(s, n=14):
    d = s.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn)


def atr(df, n=14):
    tr = pd.concat([df.High - df.Low, (df.High - df.Close.shift()).abs(),
                    (df.Low - df.Close.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def trend_label(price, fast, slow) -> str:
    if price > fast > slow:
        return "up"
    if price < fast < slow:
        return "down"
    return "sideways"


def get_technicals(pair: str) -> dict:
    t = yf.Ticker(SPECIAL_SYMBOLS.get(pair, f"{pair}=X"))
    with ThreadPoolExecutor(2) as ex:
        f1 = ex.submit(t.history, period="1mo", interval="1h", timeout=10)
        f2 = ex.submit(t.history, period="6mo", interval="1d", timeout=10)
        h1, d1 = f1.result(), f2.result()
    if h1.empty or d1.empty:
        raise RuntimeError(f"no price data for {pair}")
    price = float(h1.Close.iloc[-1])
    h1e20, h1e50 = float(ema(h1.Close, 20).iloc[-1]), float(ema(h1.Close, 50).iloc[-1])
    d1e20, d1e50 = float(ema(d1.Close, 20).iloc[-1]), float(ema(d1.Close, 50).iloc[-1])
    return {
        "price": price,
        "h1_trend": trend_label(price, h1e20, h1e50), "d1_trend": trend_label(price, d1e20, d1e50),
        "h1_ema20": h1e20, "h1_ema50": h1e50, "h1_rsi": float(rsi(h1.Close).iloc[-1]), "h1_atr": float(atr(h1).iloc[-1]),
        "d1_ema20": d1e20, "d1_ema50": d1e50, "d1_rsi": float(rsi(d1.Close).iloc[-1]), "d1_atr": float(atr(d1).iloc[-1]),
        "change_5d_pct": float((price / d1.Close.iloc[-6] - 1) * 100) if len(d1) > 6 else 0.0,
        "prev_day_high": float(d1.High.iloc[-2]), "prev_day_low": float(d1.Low.iloc[-2]),
        "20d_high": float(d1.High.iloc[-20:].max()), "20d_low": float(d1.Low.iloc[-20:].min()),
        "last_24h_high": float(h1.High.iloc[-24:].max()), "last_24h_low": float(h1.Low.iloc[-24:].min()),
    }


def quote_to_usd(quote: str) -> float:
    if quote == "USD":
        return 1.0
    for sym, inv in ((f"{quote}USD=X", False), (f"USD{quote}=X", True)):
        try:
            p = float(yf.Ticker(sym).history(period="5d").Close.iloc[-1])
            return 1 / p if inv else p
        except Exception:
            continue
    return 1.0


def lot_size(pair: str, sl_distance: float, risk_usd: float) -> tuple[float, float]:
    contract = {"XAUUSD": 100, "XAGUSD": 5000}.get(pair, 100_000)
    quote = "USD" if pair in SPECIAL_SYMBOLS else pair[3:]
    loss_per_lot = sl_distance * contract * quote_to_usd(quote)
    lots = max(0.0, int(risk_usd / loss_per_lot * 100) / 100)
    return lots, loss_per_lot


# ----------------------------------------------------------------- AI
def _extract_json(text: str) -> dict:
    text = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S)
    return json.loads(text[text.index("{"): text.rindex("}") + 1])


def _slow_penalty(model_id: str) -> int:
    """Big 'thinking' models are slow; try the quicker ones first."""
    m = model_id.lower()
    return sum(x in m for x in ("r1", "reason", "thinking", "405b", "340b", "ultra", "qwq", "think"))


async def _one_call(model: str, system: str, user: str) -> dict:
    client = AsyncOpenAI(base_url="https://integrate.api.nvidia.com/v1", api_key=next(_key_cycle),
                         timeout=LLM_TIMEOUT_S, max_retries=0)
    resp = await asyncio.wait_for(client.chat.completions.create(
        model=model, temperature=0.2, max_tokens=900,
        messages=[{"role": "system", "content": "detailed thinking off\n" + system},
                  {"role": "user", "content": user}]), LLM_TIMEOUT_S + 5)
    return _extract_json(resp.choices[0].message.content)


async def ask_llm(system: str, user: str) -> dict:
    """Asks a few of your models at the same time and returns the first valid answer."""
    if not _key_cycle:
        raise RuntimeError("No NVIDIA keys found (set NVIDIA_API_KEYS)")
    models = [NVIDIA_MODEL] if NVIDIA_MODEL else sorted(MODEL_CANDIDATES, key=_slow_penalty)
    if not models:
        raise RuntimeError("No model configured: set NVIDIA_MODEL or enable models in models.yaml")
    errors = []
    for i in range(0, min(len(models), 6), LLM_PARALLEL):
        batch = models[i:i + LLM_PARALLEL]
        tasks = {asyncio.create_task(_one_call(m, system, user)): m for m in batch}
        pending = set(tasks)
        try:
            while pending:
                done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
                for t in done:
                    try:
                        result = t.result()
                        print(f"[signal] AI answered: {tasks[t]}")
                        return result
                    except Exception as e:
                        errors.append(f"{tasks[t]}: {type(e).__name__} {str(e)[:100]}")
                        print(f"[signal] model failed: {errors[-1]}")
        finally:
            for t in pending:
                t.cancel()
    raise RuntimeError("All models failed. " + " | ".join(errors[-3:]))


SYSTEM_PROMPT = """You are a disciplined professional forex analyst. You receive for ONE pair: live technicals,
trading-session status, the economic calendar, general forex headlines, and fresh web research (news/analyst
articles with their age in hours). Decide whether there is a good trade RIGHT NOW and for how long to hold it.

Rules:
- Combine ALL inputs: daily trend, hourly momentum, RSI extremes, support/resistance, central-bank/news direction
  from the research, upcoming high-impact events, and whether the session suits this pair.
- Weigh recent articles more than old ones. If the research contradicts the technicals, lower the confidence.
- Choose "swing" (hold days) only if the daily trend is clear AND the hourly agrees; otherwise "intraday" (hold hours).
- NO_TRADE is allowed when signals conflict, a big event is imminent, or the trend is unclear - then say
  exactly what would need to change in "wait_for".
- Never invent prices, events or news. Use only the data provided.
Reply with ONLY a JSON object:
{"action":"BUY"|"SELL"|"NO_TRADE","confidence":0-100,"horizon":"intraday"|"swing",
 "reasoning":"2-3 sentences: why this direction (technicals)",
 "news_view":"1-2 sentences: what the calendar/headlines mean for this pair",
 "research_view":"1-2 sentences: what the web research/analysts say and whether it agrees",
 "key_risks":"1 sentence: what could invalidate the trade",
 "wait_for":"only if NO_TRADE: what to wait for"}"""


# ----------------------------------------------------------------- the commands
async def timed(coro, secs, default, label):
    """Run one step with a time limit; on failure return `default` instead of hanging the command."""
    t0 = time.monotonic()
    try:
        result = await asyncio.wait_for(coro, secs)
    except Exception as e:
        print(f"[signal] {label} FAILED after {time.monotonic() - t0:.1f}s: {type(e).__name__} {str(e)[:100]}")
        return default
    print(f"[signal] {label}: {time.monotonic() - t0:.1f}s")
    return result


@app_commands.command(name="setbalance", description="Optional: save your account balance (USD) to get lot sizes in /signal")
async def setbalance(interaction: discord.Interaction, amount: app_commands.Range[float, 1, 100_000_000]):
    save_balance(interaction.user.id, amount)
    await interaction.response.send_message(f"Balance saved: **${amount:,.2f}**", ephemeral=True)


@app_commands.command(name="signal", description="Researched BUY/SELL signal: entry, exit and how long to hold")
@app_commands.describe(pair="Currency pair, e.g. EURUSD, GBP/JPY, USDZAR, or gold",
                       risk="How aggressive the setup should be (default: medium)")
@app_commands.choices(risk=[app_commands.Choice(name="Low risk", value="low"),
                            app_commands.Choice(name="Medium risk", value="medium"),
                            app_commands.Choice(name="High risk", value="high")])
async def signal(interaction: discord.Interaction, pair: str, risk: Optional[app_commands.Choice[str]] = None):
    await interaction.response.defer(thinking=True)
    try:
        await asyncio.wait_for(_run_signal(interaction, pair, risk), TOTAL_TIMEOUT_S)
    except asyncio.TimeoutError:
        await interaction.followup.send("That took too long and was stopped. Please try `/signal` again in a minute.")
    except Exception as e:
        print(f"[signal] CRASH: {type(e).__name__}: {e}")
        await interaction.followup.send(f"Something went wrong: `{clip(f'{type(e).__name__}: {e}', 300)}`")


async def _run_signal(interaction: discord.Interaction, pair: str, risk: Optional[app_commands.Choice[str]]):
    pair_name = parse_pair(pair)
    if not pair_name:
        return await interaction.followup.send(
            f"I don't recognise **{clip(pair, 30)}** as a currency pair. Try something like `EURUSD`, `GBP/JPY`, `USDZAR` or `gold`.")
    risk_key = risk.value if risk else "medium"
    profile = RISK_PROFILES[risk_key]

    now = datetime.now(timezone.utc)
    if not market_open(now):
        return await interaction.followup.send("The forex market is closed (weekend). It reopens Sunday ~21:00 UTC (23:00 Eswatini time). Ask me again then.")

    t_start = time.monotonic()
    tech, events, heads, research = await asyncio.gather(
        timed(asyncio.to_thread(get_technicals, pair_name), PRICE_TIMEOUT_S, None, "prices"),
        timed(fetch_calendar(pair_name, now), FETCH_TIMEOUT_S, [], "calendar"),
        timed(fetch_headlines(), FETCH_TIMEOUT_S, [], "headlines"),
        timed(web_research(pair_name), FETCH_TIMEOUT_S, [], "web research"))
    if tech is None:
        return await interaction.followup.send(
            f"Couldn't get price data for **{pair_name}** right now (the price source is slow or down). Try again in a minute.")

    sess = session_info(pair_name, now)

    # hard news filter in CODE: never enter right around a big release
    imminent = [e for e in events if e["impact"] == "High" and -30 <= e["minutes_from_now"] <= 30]
    if imminent:
        e = imminent[0]
        return await interaction.followup.send(embed=discord.Embed(
            title=f"⛔ {pair_name}: NO TRADE - news window",
            description=f"**{e['currency']} {e['title']}** is "
                        f"{'in ' + str(e['minutes_from_now']) + ' min' if e['minutes_from_now'] >= 0 else 'just out'}. "
                        f"Spreads spike and price whipsaws around big news. Ask me again around {local(e['when'] + timedelta(minutes=30))} Eswatini time.",
            color=discord.Color.red()))

    payload = json.dumps({
        "pair": pair_name, "utc_time": now.isoformat(timespec="minutes"),
        "technicals": {k: (round(v, 5) if isinstance(v, float) else v) for k, v in tech.items()},
        "session": sess,
        "upcoming_events": [{k: v for k, v in e.items() if k != "when"} for e in events[:10]],
        "general_headlines": heads,
        "web_research": research,
    })
    print(f"[signal] data gathered in {time.monotonic() - t_start:.1f}s")
    try:
        ai = await ask_llm(SYSTEM_PROMPT, payload)
    except Exception as e:
        return await interaction.followup.send(f"AI analysis failed: `{clip(e, 400)}`")
    print(f"[signal] total {time.monotonic() - t_start:.1f}s")

    action = str(ai.get("action", "NO_TRADE")).upper().strip()
    conf = to_int(ai.get("confidence", 0))
    horizon = "swing" if str(ai.get("horizon", "")).lower().startswith("swing") else "intraday"

    if action not in ("BUY", "SELL") or conf < profile["min_conf"]:
        why = clip(ai.get("reasoning", ""), 1500)
        if action in ("BUY", "SELL"):
            why = (f"The setup leans **{action}**, but my confidence is only {conf}% and {risk_key} risk needs "
                   f"{profile['min_conf']}%+. Skipping protects your account.\n\n" + why)
        emb = discord.Embed(title=f"⏸️ {pair_name}: NO TRADE right now", description=why, color=discord.Color.orange())
        emb.add_field(name="📰 News", value=clip(ai.get("news_view")), inline=False)
        emb.add_field(name="🌐 Research", value=clip(ai.get("research_view")), inline=False)
        emb.add_field(name="⏳ Wait for", value=clip(ai.get("wait_for") or ai.get("key_risks")), inline=False)
        emb.add_field(name="🕒 Session", value=f"{', '.join(sess['active'])}. {sess['note']}", inline=False)
        return await interaction.followup.send(embed=emb)

    # ---- levels, hold time and timing are calculated by code, not by the AI
    price = tech["price"]
    unit = tech["h1_atr"] if horizon == "intraday" else tech["d1_atr"]
    sl_dist = unit * profile["sl_atr"] * (1.0 if horizon == "intraday" else 0.6)
    tp_dist = sl_dist * profile["rr"]
    sign = 1 if action == "BUY" else -1
    sl, tp1, tp2 = price - sign * sl_dist, price + sign * sl_dist, price + sign * tp_dist
    dec = decimals(pair_name)

    bars = max(1.0, (tp_dist / unit) ** 2)             # random-walk estimate of bars needed to reach target
    hours = bars if horizon == "intraday" else bars * 24
    lo_h, hi_h = max(1, round(hours * 0.7)), max(2, round(hours * 1.6))
    time_stop = min(now + timedelta(hours=hi_h), friday_close(now))
    if horizon == "intraday":
        hold_txt = f"about **{lo_h}-{hi_h} hours**"
    else:
        hold_txt = f"about **{max(1, round(lo_h / 24))}-{max(2, round(hi_h / 24))} days**"
    capped = (now + timedelta(hours=hi_h)) > friday_close(now)

    # when to enter
    soon = [e for e in events if e["impact"] == "High" and 30 < e["minutes_from_now"] <= 90]
    if soon:
        wait_until = soon[0]["when"] + timedelta(minutes=30)
        entry_txt = (f"⏳ **Wait.** {soon[0]['currency']} {soon[0]['title']} is at {local(soon[0]['when'])}. "
                     f"Run `/signal` again after {local(wait_until)} Eswatini time.")
    elif sess["quality"] == 1 and not sess["pair_session_match"]:
        w = next_good_window(pair_name, now)
        entry_txt = (f"⏳ **Wait for liquidity.** Quiet hours now. Better volume from **{local(w)}** Eswatini time. "
                     f"Run `/signal` again then for a fresh check.")
    else:
        entry_txt = f"✅ **Enter now** at market (~{price:.{dec}f})."

    # events that fall inside the hold window -> tell the user to be out before them
    window_end = now + timedelta(hours=hi_h)
    risky = [e for e in events if e["impact"] == "High" and 0 < e["minutes_from_now"] and e["when"] <= window_end]

    emb = discord.Embed(
        title=f"{'🟢 BUY' if action == 'BUY' else '🔴 SELL'} {pair_name}  ·  {'Intraday' if horizon == 'intraday' else 'Swing'} trade",
        description=clip(ai.get("reasoning", ""), 1500),
        color=discord.Color.green() if action == "BUY" else discord.Color.red())
    emb.add_field(name="When to enter", value=entry_txt, inline=False)
    emb.add_field(name="Stop loss", value=f"{sl:.{dec}f}")
    emb.add_field(name="Take profit 1", value=f"{tp1:.{dec}f}")
    emb.add_field(name="Take profit 2", value=f"{tp2:.{dec}f}")
    emb.add_field(name="Confidence", value=f"{conf}%")
    emb.add_field(name="Reward : Risk", value=f"1 : {profile['rr']:g}")
    emb.add_field(name="Risk level", value=risk_key.title())

    exit_lines = [f"• Reach **TP1**: close half and move your stop to the entry price (can't lose then).",
                  f"• Reach **TP2**: close the rest and take the profit.",
                  f"• Hit **stop loss**: accept the small loss, don't move the stop further away.",
                  f"• **Time stop:** if neither is hit by **{local(time_stop)}** Eswatini time, close it manually."
                  + (" (Closed before the weekend.)" if capped else "")]
    if risky:
        exit_lines.append(f"• Close or tighten before **{risky[0]['currency']} {risky[0]['title']}** ({local(risky[0]['when'])}).")
    emb.add_field(name="⏱️ How long to hold", value=f"{hold_txt}, if the trade works.", inline=False)
    emb.add_field(name="🚪 When to sell / exit", value=clip("\n".join(exit_lines), 1000), inline=False)

    uid = str(interaction.user.id)
    bal = load_balances().get(uid)
    if bal:
        risk_usd = bal * profile["risk_pct"] / 100
        lots, loss_per_lot = await asyncio.to_thread(lot_size, pair_name, sl_dist, risk_usd)
        if lots >= 0.01:
            emb.add_field(name="💰 Position size", inline=False,
                          value=f"**{lots:.2f} lots** risks about ${risk_usd:,.2f} ({profile['risk_pct']:g}% of your ${bal:,.0f}).")
        else:
            emb.add_field(name="💰 Position size", inline=False,
                          value=f"Even 0.01 lots would risk ${loss_per_lot * 0.01:,.2f} here, too much for your balance. Skip this one.")

    emb.add_field(name="📰 News", value=clip(ai.get("news_view")), inline=False)
    emb.add_field(name="🌐 Online research", value=clip(ai.get("research_view")), inline=False)
    emb.add_field(name="⚠️ Biggest risk", value=clip(ai.get("key_risks")), inline=False)
    emb.add_field(name="🕒 Session", inline=False,
                  value=f"{', '.join(sess['active'])} (now {local(now)} Eswatini time). {sess['note']}")
    if research:
        top = research[0]
        emb.add_field(name="🔎 Latest article used", inline=False,
                      value=clip(f"{top['title']} - {top['source']}" + (f" ({top['age_hours']}h ago)" if top['age_hours'] is not None else ""), 300))
    emb.set_footer(text="Not financial advice. No signal wins every time; the 2:1 reward:risk only works if you use the stop loss." +
                        ("" if bal else " Tip: /setbalance gives lot sizes."))
    await interaction.followup.send(embed=emb)


@signal.autocomplete("pair")
async def pair_autocomplete(interaction: discord.Interaction, current: str):
    cur = re.sub(r"[^A-Za-z]", "", current or "").upper()
    names = [p for p in POPULAR if cur in p] or POPULAR
    return [app_commands.Choice(name=(f"{p[:3]}/{p[3:]}" if p not in SPECIAL_SYMBOLS else
                                      ("Gold (XAU/USD)" if p == "XAUUSD" else "Silver (XAG/USD)")), value=p)
            for p in names[:25]]


def register(tree: app_commands.CommandTree) -> None:
    """Add /signal and /setbalance to the bot's existing command tree (works with a plain discord.Client)."""
    cmds = [setbalance, signal]
    guild_cmds = getattr(tree, "_guild_commands", None) or {}
    if guild_cmds and not tree.get_commands():
        for gid in guild_cmds:
            for c in cmds:
                tree.add_command(c, guild=discord.Object(id=gid), override=True)
    else:
        for c in cmds:
            tree.add_command(c, override=True)
