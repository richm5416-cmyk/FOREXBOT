# NVIDIA-Powered Forex Discord Bot

A Discord bot that uses several NVIDIA-hosted AI models, picks the right one for each job,
and switches automatically when one is slow, rate-limited, or down.

**Read this first**
- It gives **analysis only**. It has **no live order execution**. `TRADING_MODE` can only be `paper`.
- AI signals are not advice and nothing is guaranteed to be profitable. Treat every output as a draft to check yourself.
- If anything fails (data, AI, validation, safeguards) the answer is **NO_TRADE**. It never invents a signal.

---

## 1. How it works (plain English)

```
/analyze EUR/USD
   |
   v  1. Fetch candles (Twelve Data) -> reject if missing or stale
   v  2. Calculate EMA / RSI / ATR / support / resistance in plain Python (no AI)
   v  3. Router picks a model (health, speed, strength needed) -> NVIDIA API
   v  4. Strict validator checks the AI's JSON (stop on right side? R:R ok? contradictions?)
   v  5. Risk manager: position size, daily loss limit, duplicates, stale data, spread
   v  6. Reply in Discord (BUY / SELL / NO_TRADE + reasons)
```

| File | Job |
|---|---|
| `models.yaml` | Which NVIDIA models are enabled, their strength tier, tasks and priority |
| `forexbot/ai/client.py` | Talks to NVIDIA; turns every failure into a clear category |
| `forexbot/ai/router.py` | Chooses models, fails over, enforces retry limits and deadlines |
| `forexbot/ai/health.py` | Cooldowns and circuit breaker per model |
| `forexbot/ai/credentials.py` | Holds API keys safely (never printed or logged) |
| `forexbot/ai/validator.py` | Rejects bad or contradictory AI trading output |
| `forexbot/forex/` | Market data, indicators, analyzer, risk manager |
| `forexbot/discord_app/` | Slash commands |
| `tests/` | 92 automated tests (no real API calls) |

**Routing rules:** easy jobs (chat, summaries) go to light/fast models. Analysis needs at least a
"standard" model. Multi-timeframe and validation prefer "heavy" ones. If a model fails, the next
healthy one is used immediately (no waiting). Each request has a maximum number of attempts and an
overall deadline.

**API keys:** one key is enough. With several keys the bot only switches keys on a rate limit if you set
`AI_KEY_QUOTA_SCOPE=key`. The default (`account`) assumes keys share one limit, so switching keys would
not help and is not attempted. A rejected key (401/403) is never retried.

---

## 2. Setup (about 15 minutes)

### Install Python
Python 3.10 or newer from python.org (Windows: tick "Add Python to PATH").

### Download the project and install
Windows (PowerShell) / Mac / Linux:
```
cd forexbot_project
python -m venv venv
# Windows:      venv\Scripts\activate
# Mac / Linux:  source venv/bin/activate
pip install -r requirements.txt
```

### Get your keys
1. **NVIDIA key** - go to https://build.nvidia.com/, sign in, open any model page and choose the option to
   generate an API key. Keys start with `nvapi-`. (NVIDIA's site changes; if the button moved, check
   https://docs.api.nvidia.com/nim/docs/api-quickstart.)
2. **Discord bot** - https://discord.com/developers/applications -> New Application -> Bot ->
   Reset Token (copy it once). Then OAuth2 -> URL Generator -> tick `bot` and `applications.commands`
   -> open the link to add the bot to your server.
3. **Your Discord user ID** - Discord Settings -> Advanced -> turn on Developer Mode, then right-click your
   name -> Copy User ID.
4. **Market data** - free key at https://twelvedata.com/ (check their current free-plan limits).

### Configure
Copy `.env.example` to `.env`, open it in a text editor, and replace every `replace_with_...`.
**Never share `.env`.** If a key ever leaks, delete it on the provider's site and make a new one.

### Check, then run
```
python main.py --check     # tests your settings and one tiny NVIDIA call
python main.py             # starts the bot
```
`--check` also asks NVIDIA which models your key can use and switches off the ones it cannot.

---

## 3. Discord commands

Everyone: `/analyze pair timeframe`, `/summary pair timeframe`, `/ask question`  (15-second cooldown per person)

Admins only (your ID in `ADMIN_USER_IDS`; replies are private):

| Command | What it shows |
|---|---|
| `/ai status` | Router mode, model health counts, usable keys |
| `/ai models` | Models, status, tier, what is still unverified |
| `/ai switch <model>` | Prefer one model (fallback still works and is reported) |
| `/ai auto` | Back to automatic routing |
| `/ai test` | One tiny safe test call |
| `/ai stats` | Calls, success rate, average speed, failovers |
| `/ai cooldowns` | Which models/keys are resting and for how long |
| `/ai history` | Last 10 routing decisions and failure types |

### How to test model switching
1. `/ai models` to see the models, then `/ai switch meta/llama-3.1-8b-instruct`, then `/ai test` - it should say it used that model.
2. `/ai auto` to return to normal.
3. To see failover and cooldowns without any real failures, run `python -m pytest tests/test_router.py -v` -
   it simulates rate limits, outages, timeouts, bad keys and bad replies.
4. After real use, `/ai history` and `/ai cooldowns` show any failovers that really happened.

---

## 4. Settings (`.env`)

| Setting | Meaning |
|---|---|
| `DISCORD_BOT_TOKEN`, `NVIDIA_API_KEY_1..N`, `TWELVEDATA_API_KEY` | Your secrets |
| `ADMIN_USER_IDS` | Who can use `/ai ...` (nobody if empty) |
| `AI_ROUTING_MODE` | `auto` or `manual` (manual needs `AI_DEFAULT_MODEL`) |
| `AI_REQUEST_TIMEOUT_SECONDS` | Longest single call |
| `AI_MAX_RETRIES` | Extra attempts per request (total attempts = this + 1, across models) |
| `AI_OVERALL_DEADLINE_SECONDS` | Hard limit for one request including failovers |
| `AI_MAX_CONCURRENT_REQUESTS` | Prevents flooding NVIDIA |
| `ACCOUNT_BALANCE`, `RISK_PER_TRADE_PCT`, `MAX_DAILY_LOSS_PCT`, `MAX_OPEN_POSITIONS`, `MIN_RISK_REWARD` | Safeguards |

Startup refuses to run if a setting is invalid and tells you which one.
Adding or removing a model = edit `models.yaml` and restart. No code changes.

---

## 5. Keep it running 24/7 (Linux VPS)

```
sudo useradd -r -m forexbot
sudo mkdir /opt/forexbot && sudo chown forexbot /opt/forexbot
# copy the project into /opt/forexbot, create .env there, then:
cd /opt/forexbot && sudo -u forexbot python3 -m venv venv && sudo -u forexbot venv/bin/pip install -r requirements.txt
sudo cp forexbot.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now forexbot
sudo journalctl -u forexbot -f        # live logs
```
Duplicate-signal protection and daily-loss tracking are saved to `data/state.json`, so a restart does not
forget them. Free "bot hosts" are fine for experiments but do not put real keys on hosts you cannot trust.

---

## 6. Honest limitations

- **Not tested against live services.** The build environment could not reach NVIDIA, Discord or Twelve Data.
  What *was* tested: the HTTP client against a local fake server, and all routing, validation, risk and command
  logic with mocks (92 tests). Your first `python main.py --check` is the real connectivity test.
- The Twelve Data code follows their public docs but is unverified against the live API.
- **JSON mode is not assumed.** `supports_json` is empty for every model, so the bot relies on the prompt plus strict
  validation. Models marked `listed_in_docs` appeared in NVIDIA's LLM API reference on 2026-10-21; that does not
  guarantee your key can use them. Context sizes are unknown, so no context filtering is done.
- **Spread** is unknown with Twelve Data, so the spread check is skipped (the reply does not claim otherwise).
- **No news feed.** The `fundamental_analysis` route exists in `models.yaml` but nothing supplies news, so
  `/analyze` is technical only. Add a real news source before using that route.
- Position sizing supports USD-quoted pairs (EUR/USD, GBP/USD) and USD-based pairs (USD/JPY). Crosses are refused.
- Paper positions are only opened if `AUTO_PAPER_TRADE=true`, and are not closed automatically.
- "Preservation of existing bot functionality" could not be tested: no existing bot code was provided, so this is a new build.
- Tested on Linux with Python 3.12 only.
