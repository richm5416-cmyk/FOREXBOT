import json
import math

import pytest

from forexbot.ai.router import AIRouter
from forexbot.ai.validator import AnalysisValidationError, extract_json, validate_analysis
from forexbot.config import Settings
from forexbot.errors import AIError, AIErrorKind as K
from forexbot.forex import indicators
from forexbot.forex.analyzer import ForexAnalyzer
from forexbot.forex.market_data import Candle, MarketDataError, MarketSnapshot, parse_twelvedata
from forexbot.forex.risk import RiskManager, pip_value_per_lot_usd
from tests.conftest import build_router, make_registry

NOW = 1_800_000_000.0
BASE = {"NVIDIA_API_KEY_1": "nvapi-abcdefgh", "DISCORD_BOT_TOKEN": "x" * 40}


def settings(tmp_path, **kw):
    return Settings.from_env({**BASE, "STATE_FILE": str(tmp_path / "state.json"), **kw})


def make_candles(n=120, end=NOW, interval=3600, start_price=1.1000, drift=0.0002):
    out = []
    for i in range(n):
        base = start_price + i * drift + 0.0006 * math.sin(i / 3)
        out.append(Candle(end - (n - 1 - i) * interval, base, base + 0.0008, base - 0.0008, base + 0.0002))
    return out


def snap(candles=None, tf="1h", spread=None, pair="EUR/USD"):
    return MarketSnapshot(pair, tf, candles or make_candles(), "test", NOW, spread)


class StaticProvider:
    def __init__(self, snapshot=None, error=None):
        self.snapshot, self.error, self.calls = snapshot, error, 0

    async def get_snapshot(self, pair, tf, count=150):
        self.calls += 1
        if self.error:
            raise self.error
        s = self.snapshot
        return MarketSnapshot(pair, tf, s.candles, s.source, s.fetched_at, s.spread_pips)


# ---------------------------------------------------------------- indicators
def test_indicators_basic_sanity():
    closes = [1 + i * 0.01 for i in range(100)]
    assert indicators.rsi(closes) == 100.0
    assert indicators.ema(closes, 20)[-1] < closes[-1]
    assert indicators.pip_size("USD/JPY") == 0.01 and indicators.pip_size("EUR/USD") == 0.0001
    c = make_candles()
    ind = indicators.compute("EUR/USD", [x.open for x in c], [x.high for x in c], [x.low for x in c], [x.close for x in c])
    assert ind.trend == "bullish" and ind.atr14 > 0


def test_parse_twelvedata_and_errors():
    payload = {"status": "ok", "values": [
        {"datetime": "2026-10-21 10:00:00", "open": "1.1", "high": "1.2", "low": "1.0", "close": "1.15"},
        {"datetime": "2026-10-21 09:00:00", "open": "1.0", "high": "1.1", "low": "0.9", "close": "1.05"}]}
    s = parse_twelvedata(payload, "EUR/USD", "1h", NOW)
    assert s.candles[0].start < s.candles[1].start            # sorted oldest -> newest
    with pytest.raises(MarketDataError):
        parse_twelvedata({"status": "error", "message": "bad key"}, "EUR/USD", "1h", NOW)
    with pytest.raises(MarketDataError):
        parse_twelvedata({"values": [{"datetime": "x"}]}, "EUR/USD", "1h", NOW)


# ------------------------------------------------------------------ validator
def good_payload(**over):
    p = {"pair": "EUR/USD", "timeframe": "1h", "market_bias": "bullish", "signal": "BUY",
         "entry": 1.1000, "stop_loss": 1.0980, "take_profit": [1.1040, 1.1060], "risk_reward": 2.0,
         "supporting_evidence": ["EMA20 above EMA50"], "contradicting_evidence": [],
         "invalidation_conditions": ["close below 1.0980"], "data_quality": "ok"}
    p.update(over)
    return p


def validate(payload, **kw):
    args = dict(pair="EUR/USD", timeframe="1h", last_close=1.1001, atr=0.0020, data_time=NOW,
                analysis_time=NOW, model_id="m/x", min_rr=1.5)
    args.update(kw)
    return validate_analysis(payload, **args)


# 15 ------------------------------------------------------------------------
def test_valid_buy_passes_and_rr_is_computed_not_trusted():
    v = validate(good_payload(risk_reward=99))
    assert v.signal == "BUY" and v.risk_reward == 2.0 and v.notes


@pytest.mark.parametrize("over,fragment", [
    ({"stop_loss": 1.1020}, "stop_loss < entry"),                      # stop on wrong side
    ({"take_profit": [1.0990]}, "stop_loss < entry"),                  # target below entry
    ({"take_profit": [1.1010]}, "below the minimum"),                  # R:R 0.5
    ({"market_bias": "bearish"}, "Contradiction"),
    ({"entry": 1.1100, "stop_loss": 1.1080, "take_profit": [1.1140]}, "too far"),
    ({"stop_loss": 1.0999}, "unreasonable"),                           # stop absurdly tight
    ({"stop_loss": None}, "stop_loss"),
    ({"entry": float("nan")}, "entry"),
    ({"entry": True}, "entry"),
    ({"entry": "abc"}, "entry"),
    ({"signal": "STRONG BUY"}, "signal must be"),
    ({"pair": "GBP/USD"}, "not EUR/USD"),
    ({"supporting_evidence": []}, "supporting evidence"),
    ({"invalidation_conditions": []}, "invalidation"),
    ({"data_quality": "poor"}, "data quality"),
    ({"take_profit": []}, "take_profit"),
])
def test_invalid_signals_are_rejected(over, fragment):
    with pytest.raises(AnalysisValidationError) as e:
        validate(good_payload(**over))
    assert fragment.lower() in str(e.value).lower()


def test_sell_ordering_and_no_trade_passthrough():
    v = validate(good_payload(signal="SELL", market_bias="bearish", entry=1.1000, stop_loss=1.1020,
                              take_profit=[1.0960]))
    assert v.signal == "SELL"
    with pytest.raises(AnalysisValidationError):
        validate(good_payload(signal="SELL", market_bias="bearish", stop_loss=1.0980, take_profit=[1.0960]))
    nt = validate({"signal": "NO_TRADE", "market_bias": "neutral"})
    assert nt.signal == "NO_TRADE" and nt.entry is None


def test_extract_json_handles_fences_and_rejects_garbage():
    assert extract_json("```json\n{\"a\": 1}\n```") == {"a": 1}
    assert extract_json("Sure! {\"a\": 1} hope it helps") == {"a": 1}
    for bad in ("no json here", "{broken", "[1,2]"):
        with pytest.raises(AnalysisValidationError):
            extract_json(bad)


# ----------------------------------------------------------------------- risk
def make_signal(**kw):
    return validate(good_payload(**kw))


def test_position_size_is_computed_outside_the_llm(tmp_path):
    rm = RiskManager(settings(tmp_path, ACCOUNT_BALANCE="10000", RISK_PER_TRADE_PCT="1"), clock=lambda: NOW)
    lots, risk, err = rm.position_size("EUR/USD", 1.1000, 1.0980)      # 20 pip stop, $100 risk -> 0.5 lot
    assert err is None and lots == 0.5 and risk == 100
    assert pip_value_per_lot_usd("USD/JPY", 150.0) == pytest.approx(6.667, rel=1e-3)
    assert pip_value_per_lot_usd("EUR/GBP", 0.85) is None
    _, _, err = rm.position_size("EUR/GBP", 0.85, 0.84)
    assert "not supported" in err


def test_tiny_account_cannot_trade(tmp_path):
    rm = RiskManager(settings(tmp_path, ACCOUNT_BALANCE="100"), clock=lambda: NOW)
    d = rm.evaluate(make_signal(), snap(), NOW)
    assert not d.approved and "too small" in " ".join(d.reasons)


def test_risk_gate_blocks_stale_spread_duplicates_daily_loss_and_limits(tmp_path):
    s = settings(tmp_path, ACCOUNT_BALANCE="10000", MAX_OPEN_POSITIONS="1")
    rm = RiskManager(s, clock=lambda: NOW)
    sig = make_signal()
    assert rm.evaluate(sig, snap(), NOW).approved
    assert "stale" in " ".join(rm.evaluate(sig, snap(), NOW + 99999).reasons).lower()
    assert "spread" in " ".join(rm.evaluate(sig, snap(spread=9.0), NOW).reasons).lower()
    rm.register_signal(sig, NOW)
    assert "Duplicate" in " ".join(rm.evaluate(sig, snap(), NOW + 60).reasons)
    later = NOW + 241 * 60                                    # duplicate window (240 min) has passed
    assert rm.evaluate(sig, snap(make_candles(end=later)), later).approved
    rm2 = RiskManager(settings(tmp_path, ACCOUNT_BALANCE="10000", STATE_FILE=str(tmp_path / "s2.json")), clock=lambda: NOW)
    rm2.record_result(-400)                       # 4% loss > 3% limit
    assert "daily loss" in " ".join(rm2.evaluate(sig, snap(), NOW).reasons).lower()
    rm3 = RiskManager(settings(tmp_path, ACCOUNT_BALANCE="10000", MAX_OPEN_POSITIONS="1",
                               STATE_FILE=str(tmp_path / "s3.json")), clock=lambda: NOW)
    rm3.open_paper_position(sig, 0.5)
    assert "open" in " ".join(rm3.evaluate(sig, snap(), NOW).reasons).lower()


def test_duplicate_protection_survives_restart(tmp_path):
    s = settings(tmp_path, ACCOUNT_BALANCE="10000")
    RiskManager(s, clock=lambda: NOW).register_signal(make_signal(), NOW)
    after_restart = RiskManager(s, clock=lambda: NOW)
    assert "Duplicate" in " ".join(after_restart.evaluate(make_signal(), snap(), NOW + 10).reasons)


def test_live_trading_cannot_be_enabled(tmp_path):
    s = settings(tmp_path, ACCOUNT_BALANCE="10000")
    s.trading_mode = "live"                                    # even if forced in code
    d = RiskManager(s, clock=lambda: NOW).evaluate(make_signal(), snap(), NOW)
    assert not d.approved and "Live trading is not enabled" in " ".join(d.reasons)


# ------------------------------------------------------------------- analyzer
def analyzer_for(tmp_path, clock, script, provider, **env):
    reg = make_registry(extra_tasks=())
    router, client, *_ = build_router(script, clock, registry=reg)
    s = settings(tmp_path, ACCOUNT_BALANCE="10000", **env)
    return ForexAnalyzer(provider, router, RiskManager(s, clock=lambda: NOW), s, clock=lambda: NOW), client


async def test_good_flow_produces_signal_with_risk_approval(tmp_path, clock):
    c = make_candles()
    last = c[-1].close
    atr = 0.0016
    payload = good_payload(entry=round(last, 5), stop_loss=round(last - 0.0020, 5),
                           take_profit=[round(last + 0.0040, 5)], risk_reward=2)
    an, client = analyzer_for(tmp_path, clock, {"meta/heavy-d": [json.dumps(payload)], "meta/mid-b": [json.dumps(payload)]},
                              StaticProvider(snap(c)))
    r = await an.analyze("EURUSD", "H1")
    assert r.signal == "BUY" and r.risk.approved and r.risk.lots > 0 and r.model_id


# 14 ------------------------------------------------------------------------
async def test_stale_market_data_means_no_trade_and_no_ai_call(tmp_path, clock):
    old = make_candles(end=NOW - 10 * 3600)
    an, client = analyzer_for(tmp_path, clock, {"meta/mid-b": ["{}"]}, StaticProvider(snap(old)))
    r = await an.analyze("EUR/USD", "H1")
    assert r.signal == "NO_TRADE" and "stale" in r.reasons[0].lower() and not client.calls


async def test_missing_market_data_means_no_trade(tmp_path, clock):
    an, client = analyzer_for(tmp_path, clock, {}, StaticProvider(error=MarketDataError("down")))
    r = await an.analyze("EUR/USD", "H1")
    assert r.signal == "NO_TRADE" and r.error_category == "data" and not client.calls


async def test_not_enough_candles_and_unsupported_pair(tmp_path, clock):
    an, client = analyzer_for(tmp_path, clock, {}, StaticProvider(snap(make_candles(20))))
    assert (await an.analyze("EUR/USD", "H1")).signal == "NO_TRADE"
    r = await an.analyze("EUR/CHF", "H1")
    assert r.signal == "NO_TRADE" and "not enabled" in r.reasons[0]
    r = await an.analyze("nonsense", "H1")
    assert r.signal == "NO_TRADE"


# 16 ------------------------------------------------------------------------
async def test_all_models_down_gives_no_trade_not_a_manufactured_signal(tmp_path, clock):
    script = {m: [AIError(K.SERVER)] for m in ("meta/mid-b", "meta/mid-c", "meta/heavy-d")}
    an, client = analyzer_for(tmp_path, clock, script, StaticProvider(snap()))
    r = await an.analyze("EUR/USD", "H1")
    assert r.signal == "NO_TRADE" and r.error_category == "ai" and r.validated is None and r.risk is None
    assert "no earlier analysis was reused" in r.reasons[0]


async def test_garbage_or_invalid_ai_output_means_no_trade(tmp_path, clock):
    for reply in ("I think EUR/USD will go up!", "{not json", json.dumps(good_payload(stop_loss=2.0))):
        an, _ = analyzer_for(tmp_path, clock, {"meta/mid-b": [reply], "meta/mid-c": [reply], "meta/heavy-d": [reply]},
                             StaticProvider(snap()))
        r = await an.analyze("EUR/USD", "H1")
        assert r.signal == "NO_TRADE" and r.error_category == "validation"


async def test_duplicate_signal_is_blocked_on_second_request(tmp_path, clock):
    c = make_candles()
    last = c[-1].close
    payload = json.dumps(good_payload(entry=round(last, 5), stop_loss=round(last - 0.0020, 5),
                                      take_profit=[round(last + 0.0040, 5)]))
    an, _ = analyzer_for(tmp_path, clock, {"meta/heavy-d": [payload], "meta/mid-b": [payload]}, StaticProvider(snap(c)))
    first = await an.analyze("EUR/USD", "H1")
    second = await an.analyze("EUR/USD", "H1")
    assert first.risk.approved and not second.risk.approved and "Duplicate" in " ".join(second.risk.reasons)
