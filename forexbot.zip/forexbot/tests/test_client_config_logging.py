import io
import json
import logging

import pytest

from forexbot.ai.client import parse_chat_response
from forexbot.ai.credentials import CredentialManager
from forexbot.config import Settings
from forexbot.errors import AIError, AIErrorKind as K, ConfigError
from forexbot.logging_config import JsonFormatter, RedactingFilter, redact, register_secret

OK_BODY = json.dumps({"choices": [{"message": {"content": "hello"}, "finish_reason": "stop"}],
                      "usage": {"total_tokens": 5}})


def kind_of(status, body="", headers=None):
    with pytest.raises(AIError) as e:
        parse_chat_response(status, headers or {}, body)
    return e.value


def test_http_status_classification():
    assert kind_of(429, headers={"Retry-After": "12"}).kind == K.RATE_LIMIT
    assert kind_of(429, headers={"retry-after": "12"}).retry_after == 12
    assert kind_of(401).kind == K.AUTH and kind_of(403).kind == K.AUTH
    assert kind_of(400, "bad").kind == K.BAD_REQUEST
    assert kind_of(404).kind == K.NOT_FOUND
    assert kind_of(408).kind == K.TIMEOUT
    assert kind_of(500).kind == K.SERVER and kind_of(503).kind == K.SERVER


def test_malformed_and_empty_responses():
    assert kind_of(200, "<html>oops").kind == K.MALFORMED
    assert kind_of(200, "{}").kind == K.MALFORMED
    assert kind_of(200, json.dumps({"choices": []})).kind == K.MALFORMED
    assert kind_of(200, json.dumps({"choices": [{"message": {"content": None}}]})).kind == K.EMPTY
    assert kind_of(200, json.dumps({"choices": [{"message": {"content": "  "}}]})).kind == K.EMPTY
    assert kind_of(200, json.dumps({"choices": [{"message": {"content": "<think>hmm</think>"}}]})).kind == K.EMPTY


def test_success_parses_and_strips_think_blocks():
    assert parse_chat_response(200, {}, OK_BODY).text == "hello"
    body = json.dumps({"choices": [{"message": {"content": "<think>reasoning</think>\nanswer"}}]})
    assert parse_chat_response(200, {}, body).text == "answer"


# 18 redaction ----------------------------------------------------------------
def test_api_keys_are_redacted_in_logs():
    secret = "nvapi-SuperSecretKey1234567890"
    register_secret(secret)
    stream = io.StringIO()
    h = logging.StreamHandler(stream)
    h.setFormatter(JsonFormatter())
    h.addFilter(RedactingFilter())
    lg = logging.getLogger("redaction-test")
    lg.handlers[:] = [h]
    lg.propagate = False
    lg.error("failed with key %s and Bearer abcdefgh12345678", secret)
    lg.info("event", extra={"fields": {"detail": f"token={secret}"}})
    try:
        raise RuntimeError(f"boom {secret}")
    except RuntimeError:
        lg.exception("crashed")
    out = stream.getvalue()
    assert secret not in out and "SuperSecret" not in out and "abcdefgh12345678" not in out
    assert "[REDACTED]" in out


def test_discord_token_pattern_redacted():
    tok = "MTIzNDU2Nzg5MDEyMzQ1Njc4.GabcDE.abcdefghijklmnopqrstuvwxyz1"
    assert tok not in redact(f"login {tok}")


def test_error_messages_never_contain_keys():
    body = json.dumps({"error": "bad key nvapi-LeakedKey123456789"})
    e = kind_of(400, body)
    assert "nvapi-LeakedKey" not in str(e)


def test_key_lease_repr_hides_secret():
    cm = CredentialManager(["nvapi-AAAABBBBCCCC"])
    lease = cm.select()
    assert "AAAABBBB" not in repr(lease) and "AAAABBBB" not in str(cm.summary())


def test_credentials_replace_and_disable():
    cm = CredentialManager(["nvapi-one11111", "nvapi-two22222"])
    cm.report_auth_failure("key1")
    assert cm.select().label == "key2"
    assert cm.replace("key1", "nvapi-new33333") and cm.has_usable({"key2"})
    cm.disable("key1"); cm.disable("key2")
    assert cm.select() is None


# config ---------------------------------------------------------------------
BASE = {"NVIDIA_API_KEY_1": "nvapi-abcdefgh", "DISCORD_BOT_TOKEN": "x" * 40}


def test_single_key_and_defaults_work():
    s = Settings.from_env(BASE)
    assert s.nvidia_keys == ["nvapi-abcdefgh"] and s.trading_mode == "paper" and s.key_quota_scope == "account"


def test_multiple_keys_collected_in_order():
    s = Settings.from_env({**BASE, "NVIDIA_API_KEY_2": "nvapi-second99", "NVIDIA_API_KEY_10": "nvapi-tenth000"})
    assert s.nvidia_keys == ["nvapi-abcdefgh", "nvapi-second99", "nvapi-tenth000"]


@pytest.mark.parametrize("bad", [
    {"NVIDIA_BASE_URL": "https://api.openai.com/v1"},
    {"NVIDIA_BASE_URL": "http://integrate.api.nvidia.com/v1"},
    {"TRADING_MODE": "live"},
    {"AI_ROUTING_MODE": "random"},
    {"AI_REQUEST_TIMEOUT_SECONDS": "fast"},
    {"RISK_PER_TRADE_PCT": "50"},
    {"ADMIN_USER_IDS": "abc"},
    {"SUPPORTED_PAIRS": "EURUSD"},
])
def test_invalid_settings_are_rejected_with_clear_message(bad):
    with pytest.raises(ConfigError) as e:
        Settings.from_env({**BASE, **bad})
    assert "Settings problems" in str(e.value)


def test_missing_and_placeholder_keys_rejected():
    with pytest.raises(ConfigError):
        Settings.from_env({"DISCORD_BOT_TOKEN": "x" * 40})
    with pytest.raises(ConfigError):
        Settings.from_env({"NVIDIA_API_KEY_1": "replace_with_your_key", "DISCORD_BOT_TOKEN": "x" * 40})
    with pytest.raises(ConfigError):
        Settings.from_env({"NVIDIA_API_KEY_1": "nvapi-abcdefgh", "DISCORD_BOT_TOKEN": "replace_with_your_discord_token"})
