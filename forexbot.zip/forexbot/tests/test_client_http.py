"""Runs the REAL NvidiaClient against a local fake server (no internet, no real key)."""
import asyncio
import json

import pytest
from aiohttp import web

from forexbot.ai.client import NvidiaClient
from forexbot.errors import AIError, AIErrorKind as K


@pytest.fixture
async def server():
    seen = {}

    async def chat(request):
        seen["auth"] = request.headers.get("Authorization")
        seen["body"] = await request.json()
        mode = request.query.get("mode") or seen.get("mode", "ok")
        mode = seen.get("mode", "ok")
        if mode == "429":
            return web.Response(status=429, headers={"Retry-After": "7"}, text="slow down")
        if mode == "500":
            return web.Response(status=500, text="boom")
        if mode == "html":
            return web.Response(status=200, text="<html>gateway</html>")
        if mode == "hang":
            await asyncio.sleep(5)
        return web.json_response({"choices": [{"message": {"content": "pong"}, "finish_reason": "stop"}],
                                  "usage": {"total_tokens": 3}})

    async def models(request):
        seen["auth"] = request.headers.get("Authorization")
        return web.json_response({"data": [{"id": "meta/llama-3.1-8b-instruct"}, {"id": "x/y"}]})

    app = web.Application()
    app.router.add_post("/v1/chat/completions", chat)
    app.router.add_get("/v1/models", models)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    yield f"http://127.0.0.1:{port}/v1", seen
    await runner.cleanup()


async def call(base, **kw):
    c = NvidiaClient(base)
    try:
        return await c.chat(model="m/x", messages=[{"role": "user", "content": "ping"}], api_key="nvapi-TESTKEY123",
                            max_tokens=5, temperature=0.1, timeout=kw.pop("timeout", 3), **kw)
    finally:
        await c.close()


async def test_real_request_format_and_success(server):
    base, seen = server
    res = await call(base)
    assert res.text == "pong" and res.latency > 0
    assert seen["auth"] == "Bearer nvapi-TESTKEY123"
    assert seen["body"]["model"] == "m/x" and seen["body"]["stream"] is False
    assert "response_format" not in seen["body"]                  # JSON mode only when explicitly requested


async def test_json_mode_flag_sends_response_format(server):
    base, seen = server
    await call(base, json_mode=True)
    assert seen["body"]["response_format"] == {"type": "json_object"}


@pytest.mark.parametrize("mode,kind", [("429", K.RATE_LIMIT), ("500", K.SERVER), ("html", K.MALFORMED)])
async def test_real_http_errors_are_classified(server, mode, kind):
    base, seen = server
    seen["mode"] = mode
    with pytest.raises(AIError) as e:
        await call(base)
    assert e.value.kind == kind
    if mode == "429":
        assert e.value.retry_after == 7


async def test_real_timeout_is_classified(server):
    base, seen = server
    seen["mode"] = "hang"
    with pytest.raises(AIError) as e:
        await call(base, timeout=0.3)
    assert e.value.kind == K.TIMEOUT


async def test_connection_refused_is_network_error():
    with pytest.raises(AIError) as e:
        await call("http://127.0.0.1:9/v1")
    assert e.value.kind == K.NETWORK


async def test_list_models(server):
    base, seen = server
    c = NvidiaClient(base)
    try:
        assert await c.list_models("nvapi-TESTKEY123") == {"meta/llama-3.1-8b-instruct", "x/y"}
    finally:
        await c.close()
