import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

import asyncio
import pytest

from forexbot.ai.client import ChatResult
from forexbot.ai.credentials import CredentialManager
from forexbot.ai.health import HealthMonitor
from forexbot.ai.registry import registry_from_dict
from forexbot.ai.router import AIRouter
from forexbot.errors import AIError, AIErrorKind
from forexbot.logging_config import clear_secrets


class FakeClock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t

    async def sleep(self, s):
        self.t += s


class FakeClient:
    """script: {model_id: [outcome, ...]}; outcome = str (success text) | AIError | callable."""

    def __init__(self, script, clock=None, delay=0.0):
        self.script = {k: list(v) for k, v in script.items()}
        self.calls = []
        self.clock = clock
        self.delay = delay
        self.inflight = 0
        self.max_inflight = 0

    async def chat(self, *, model, messages, api_key, max_tokens, temperature, timeout, json_mode=False):
        self.calls.append({"model": model, "key": api_key, "json_mode": json_mode, "max_tokens": max_tokens})
        self.inflight += 1
        self.max_inflight = max(self.max_inflight, self.inflight)
        try:
            if self.delay:
                await asyncio.sleep(self.delay)
            queue = self.script.get(model, [])
            outcome = queue.pop(0) if len(queue) > 1 else (queue[0] if queue else AIError(AIErrorKind.SERVER, 'unscripted'))
            if isinstance(outcome, Exception):
                raise outcome
            return ChatResult(text=outcome, model=model, latency=0.1)
        finally:
            self.inflight -= 1


def make_registry(models=None, extra_tasks=()):
    models = models or [
        ("meta/light-a", "light", 10),
        ("meta/mid-b", "standard", 20),
        ("meta/mid-c", "standard", 30),
        ("meta/heavy-d", "heavy", 40),
    ]
    tasks = ["quick_summary", "technical_analysis", "multi_timeframe", "discord_chat", "complex_reasoning", *extra_tasks]
    return registry_from_dict({
        "models": [{"id": i, "tier": t, "priority": p, "tasks": tasks, "timeout_s": 10} for i, t, p in models],
        "routing": {
            "quick_summary": {"min_tier": "light", "preferred_tier": "light"},
            "discord_chat": {"min_tier": "light", "preferred_tier": "light"},
            "technical_analysis": {"min_tier": "standard", "preferred_tier": "standard", "time_sensitive": True},
            "multi_timeframe": {"min_tier": "standard", "preferred_tier": "heavy", "time_sensitive": True},
            "complex_reasoning": {"min_tier": "heavy", "preferred_tier": "heavy"},
        },
    })


@pytest.fixture
def clock():
    return FakeClock()


@pytest.fixture(autouse=True)
def _clean_secrets():
    clear_secrets()
    yield
    clear_secrets()


def build_router(script, clock, *, keys=("nvapi-AAAA1111", ), scope="account", max_attempts=3,
                 registry=None, deadline=45.0, max_concurrent=5, delay=0.0):
    reg = registry or make_registry()
    health = HealthMonitor(clock=clock)
    creds = CredentialManager(list(keys), scope, clock=clock)
    client = FakeClient(script, clock, delay)
    router = AIRouter(reg, health, creds, client, max_attempts=max_attempts, overall_deadline_s=deadline,
                      max_concurrent=max_concurrent, clock=clock, sleep=clock.sleep, rng=lambda: 0.5)
    return router, client, health, creds, reg
