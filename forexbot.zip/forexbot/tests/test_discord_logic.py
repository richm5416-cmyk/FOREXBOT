import pytest

from forexbot.config import Settings
from forexbot.discord_app import logic as L
from forexbot.errors import AIError, AIErrorKind as K
from tests.conftest import build_router

BASE = {"NVIDIA_API_KEY_1": "nvapi-abcdefgh", "DISCORD_BOT_TOKEN": "x" * 40}


def make_ctx(clock, script, admins="42"):
    router, client, health, creds, reg = build_router(script, clock)
    s = Settings.from_env({**BASE, "ADMIN_USER_IDS": admins})
    return L.AppContext(s, reg, router, health, creds, analyzer=None), client


def test_admin_gate(clock):
    ctx, _ = make_ctx(clock, {})
    assert L.check_admin(ctx, 42) is None
    assert L.check_admin(ctx, 7) == L.NOT_ADMIN
    ctx2, _ = make_ctx(clock, {}, admins="")
    assert L.check_admin(ctx2, 42) == L.NO_ADMINS             # no admins configured => nobody is admin


async def test_ai_commands_end_to_end(clock):
    ctx, _ = make_ctx(clock, {"meta/light-a": ["OK"], "meta/mid-b": [AIError(K.RATE_LIMIT, retry_after=60)],
                              "meta/mid-c": ["ok"]})
    assert "passed" in await L.ai_test(ctx)
    assert "automatic" in L.ai_status(ctx)
    assert "meta/light-a" in L.ai_models(ctx) and "JSON mode unverified" in L.ai_models(ctx)
    assert "Preferred model set" in L.ai_switch(ctx, "meta/heavy-d") and "manual" in L.ai_status(ctx)
    assert "Could not switch" in L.ai_switch(ctx, "nope/nope")
    L.ai_auto(ctx)
    await ctx.router.complete("technical_analysis", [{"role": "user", "content": "x"}])
    assert "retry in" in L.ai_cooldowns(ctx)
    assert "technical_analysis" in L.ai_history(ctx) and "Failovers" in L.ai_stats(ctx)


async def test_user_commands_are_rate_limited_and_safe_on_failure(clock):
    ctx, _ = make_ctx(clock, {"meta/light-a": [AIError(K.SERVER)]})
    first = await L.ask_cmd(ctx, 5, "hello?")
    assert "unavailable" in first
    assert "wait" in await L.ask_cmd(ctx, 5, "again")


def test_outputs_never_contain_api_keys(clock):
    ctx, _ = make_ctx(clock, {})
    blob = "\n".join([L.ai_status(ctx), L.ai_models(ctx), L.ai_stats(ctx), L.ai_cooldowns(ctx), L.ai_history(ctx)])
    assert "nvapi" not in blob and "abcdefgh" not in blob


def test_bot_module_builds_all_commands(clock):
    discord = pytest.importorskip("discord")
    from forexbot.discord_app.bot import create_bot
    ctx, _ = make_ctx(clock, {})
    client = create_bot(ctx)
    names = {c.name for c in client.tree.walk_commands()} if hasattr(client, "tree") else None
    assert client is not None
