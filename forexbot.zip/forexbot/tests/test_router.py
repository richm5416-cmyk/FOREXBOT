import asyncio

import pytest

from forexbot.ai.health import Status
from forexbot.errors import (AIError, AIErrorKind as K, AllModelsUnavailable, AmbiguousFailure, ConfigError)
from tests.conftest import build_router, make_registry

MSG = [{"role": "user", "content": "hi"}]


def err(kind, **kw):
    return AIError(kind, "x", **kw)


# 1 ---------------------------------------------------------------------------
async def test_success_on_preferred_model(clock):
    r, client, *_ = build_router({"meta/mid-b": ["hello"]}, clock)
    res = await r.complete("technical_analysis", MSG)
    assert res.text == "hello" and res.model_id == "meta/mid-b" and not res.failed_over
    assert [c["model"] for c in client.calls] == ["meta/mid-b"]


async def test_easy_task_uses_light_model_hard_task_uses_heavy(clock):
    r, *_ = build_router({"meta/light-a": ["a"], "meta/heavy-d": ["d"]}, clock)
    assert (await r.complete("quick_summary", MSG)).model_id == "meta/light-a"
    assert (await r.complete("complex_reasoning", MSG)).model_id == "meta/heavy-d"


# 2 ---------------------------------------------------------------------------
async def test_rate_limit_sets_cooldown_and_honours_retry_after(clock):
    r, client, health, *_ = build_router(
        {"meta/mid-b": [err(K.RATE_LIMIT, retry_after=40)], "meta/mid-c": ["ok"]}, clock)
    res = await r.complete("technical_analysis", MSG)
    assert res.model_id == "meta/mid-c" and res.failed_over
    assert health.status("meta/mid-b") == Status.RATE_LIMITED
    assert 39 <= health.cooldown_remaining("meta/mid-b") <= 40
    assert "meta/mid-b" not in [m.id for m in r.plan("technical_analysis")]
    clock.t += 41                                   # cooldown over -> model usable again
    assert r.plan("technical_analysis")[0].id == "meta/mid-b"


# 3 ---------------------------------------------------------------------------
async def test_failover_to_backup_model_is_immediate(clock):
    r, client, *_ = build_router({"meta/mid-b": [err(K.SERVER, status=503)], "meta/mid-c": ["ok"]}, clock)
    start = clock.t
    res = await r.complete("technical_analysis", MSG)
    assert res.model_id == "meta/mid-c"
    assert clock.t == start                         # no sleeping when a backup exists
    assert "Switched from meta/mid-b" in res.note


# 4 ---------------------------------------------------------------------------
async def test_key_rotation_on_rate_limit_when_quota_is_per_key(clock):
    r, client, health, creds, _ = build_router(
        {"meta/mid-b": [err(K.RATE_LIMIT, retry_after=30), "ok"]}, clock,
        keys=("nvapi-KEYONE111", "nvapi-KEYTWO222"), scope="key")
    res = await r.complete("technical_analysis", MSG)
    assert res.model_id == "meta/mid-b" and res.key_label == "key2"
    assert [c["key"] for c in client.calls] == ["nvapi-KEYONE111", "nvapi-KEYTWO222"]
    assert health.is_available("meta/mid-b")        # per-key limit must not punish the model


# 5 ---------------------------------------------------------------------------
async def test_shared_quota_does_not_rotate_keys(clock):
    r, client, health, creds, _ = build_router(
        {"meta/mid-b": [err(K.RATE_LIMIT, retry_after=30)], "meta/mid-c": ["ok"]}, clock,
        keys=("nvapi-KEYONE111", "nvapi-KEYTWO222"), scope="account")
    res = await r.complete("technical_analysis", MSG)
    assert res.model_id == "meta/mid-c"
    first, second = client.calls[0], client.calls[1]
    assert first["model"] == "meta/mid-b" and second["model"] == "meta/mid-c"   # moved model, not "dodged" via key
    assert not health.is_available("meta/mid-b")


# 6 ---------------------------------------------------------------------------
async def test_auth_failure_single_key_stops_immediately(clock):
    r, client, health, creds, _ = build_router({"meta/mid-b": [err(K.AUTH, status=401)]}, clock)
    with pytest.raises(AllModelsUnavailable) as ei:
        await r.complete("technical_analysis", MSG)
    assert ei.value.kind == "auth"
    assert len(client.calls) == 1                   # permanent error: not retried, other models not hammered
    assert creds.summary()[0]["status"] == "authentication_failed"


async def test_auth_failure_switches_to_second_key(clock):
    r, client, health, creds, _ = build_router({"meta/mid-b": [err(K.AUTH, status=403), "ok"]}, clock,
                                               keys=("nvapi-BADKEY111", "nvapi-GOODKEY22"))
    res = await r.complete("technical_analysis", MSG)
    assert res.key_label == "key2"
    assert creds.summary()[0]["status"] == "authentication_failed"


# 7 ---------------------------------------------------------------------------
async def test_provider_outage_all_models_down_and_circuit_opens(clock):
    script = {m: [err(K.SERVER, status=500)] for m in ("meta/mid-b", "meta/mid-c", "meta/heavy-d")}
    r, client, health, *_ = build_router(script, clock, max_attempts=10)
    for _ in range(3):
        with pytest.raises(AllModelsUnavailable):
            await r.complete("technical_analysis", MSG)
    assert health.status("meta/mid-b") == Status.UNAVAILABLE       # circuit breaker open
    calls_before = len(client.calls)
    with pytest.raises(AllModelsUnavailable) as ei:
        await r.complete("technical_analysis", MSG)
    assert ei.value.kind == "no_model" and len(client.calls) == calls_before   # no calls while open


# 8 ---------------------------------------------------------------------------
async def test_timeout_fails_over(clock):
    r, client, *_ = build_router({"meta/mid-b": [err(K.TIMEOUT)], "meta/mid-c": ["ok"]}, clock)
    assert (await r.complete("technical_analysis", MSG)).model_id == "meta/mid-c"


# 9 ---------------------------------------------------------------------------
@pytest.mark.parametrize("kind", [K.MALFORMED, K.EMPTY])
async def test_malformed_or_empty_reply_fails_over(clock, kind):
    r, *_ = build_router({"meta/mid-b": [err(kind)], "meta/mid-c": ["good"]}, clock)
    assert (await r.complete("technical_analysis", MSG)).text == "good"


async def test_single_model_gets_one_backoff_retry_then_gives_up(clock):
    reg = make_registry([("meta/only", "standard", 10)])
    r, client, *_ = build_router({"meta/only": [err(K.SERVER)]}, clock, registry=reg)
    start = clock.t
    with pytest.raises(AllModelsUnavailable):
        await r.complete("technical_analysis", MSG)
    assert len(client.calls) == 2 and clock.t > start             # exactly one retry, after a backoff


# 10 --------------------------------------------------------------------------
async def test_max_attempts_is_enforced(clock):
    script = {m: [err(K.SERVER)] for m in ("meta/mid-b", "meta/mid-c", "meta/heavy-d")}
    r, client, *_ = build_router(script, clock, max_attempts=2)
    with pytest.raises(AllModelsUnavailable):
        await r.complete("technical_analysis", MSG)
    assert len(client.calls) == 2


async def test_overall_deadline_is_enforced(clock):
    reg = make_registry([("meta/only", "standard", 10)])
    r, client, *_ = build_router({"meta/only": [err(K.SERVER)]}, clock, registry=reg, deadline=1.0, max_attempts=9)
    with pytest.raises(AllModelsUnavailable):
        await r.complete("technical_analysis", MSG)
    assert len(client.calls) <= 2


async def test_permanent_errors_are_not_retried(clock):
    reg = make_registry([("meta/only", "standard", 10)])
    r, client, *_ = build_router({"meta/only": [err(K.BAD_REQUEST, status=400)]}, clock, registry=reg)
    with pytest.raises(AllModelsUnavailable):
        await r.complete("technical_analysis", MSG)
    assert len(client.calls) == 1


# 11 --------------------------------------------------------------------------
def test_invalid_model_configuration_is_rejected():
    from forexbot.ai.registry import registry_from_dict
    base = {"id": "a/b", "tier": "light", "tasks": ["discord_chat"]}
    with pytest.raises(ConfigError):
        registry_from_dict({"models": [base, base]})                                   # duplicate
    with pytest.raises(ConfigError):
        registry_from_dict({"models": [{**base, "tier": "giant"}]})                    # bad tier
    with pytest.raises(ConfigError):
        registry_from_dict({"models": [{**base, "tasks": ["make_coffee"]}]})           # unknown task
    with pytest.raises(ConfigError):
        registry_from_dict({"models": [{"id": "noslash"}]})                            # bad id
    with pytest.raises(ConfigError):
        registry_from_dict({"models": [{**base, "timeout_s": "fast"}]})                # bad number
    with pytest.raises(ConfigError):
        registry_from_dict({"models": [base], "default_model": "x/y"})                 # unknown default
    with pytest.raises(ConfigError):
        registry_from_dict({"models": []})


def test_real_models_yaml_loads():
    from forexbot.ai.registry import load_registry
    reg = load_registry("models.yaml")
    assert reg.models and reg.default_model in reg.models


# 12 --------------------------------------------------------------------------
async def test_manual_mode_prefers_chosen_model(clock):
    r, client, *_ = build_router({"meta/heavy-d": ["from heavy"]}, clock)
    r.set_manual("meta/heavy-d")
    assert (await r.complete("technical_analysis", MSG)).model_id == "meta/heavy-d"
    r.set_auto()
    assert r.mode == "auto"


async def test_manual_model_failure_falls_back_and_reports(clock):
    r, client, *_ = build_router({"meta/heavy-d": [err(K.SERVER)], "meta/mid-b": ["fallback"]}, clock)
    r.set_manual("meta/heavy-d")
    res = await r.complete("technical_analysis", MSG)
    assert res.model_id == "meta/mid-b" and res.failed_over and "meta/heavy-d" in res.note


def test_manual_switch_to_unknown_or_disabled_model_is_refused(clock):
    r, *_ , reg = build_router({}, clock)
    with pytest.raises(ConfigError):
        r.set_manual("nope/nope")
    reg.disable("meta/mid-b", "test")
    with pytest.raises(ConfigError):
        r.set_manual("meta/mid-b")


# 13 --------------------------------------------------------------------------
async def test_concurrent_requests_are_bounded(clock):
    r, client, *_ = build_router({"meta/mid-b": ["ok"]}, clock, max_concurrent=3, delay=0.01)
    msgs = [[{"role": "user", "content": f"q{i}"}] for i in range(12)]
    results = await asyncio.gather(*(r.complete("technical_analysis", m) for m in msgs))
    assert len(results) == 12 and client.max_inflight <= 3


# 17 --------------------------------------------------------------------------
async def test_identical_inflight_requests_are_deduplicated(clock):
    r, client, *_ = build_router({"meta/mid-b": ["ok"]}, clock, delay=0.02)
    results = await asyncio.gather(*(r.complete("technical_analysis", MSG) for _ in range(5)))
    assert len(client.calls) == 1 and all(x.text == "ok" for x in results)


async def test_non_repeatable_request_is_not_retried_after_ambiguous_failure(clock):
    r, client, *_ = build_router({"meta/mid-b": [err(K.TIMEOUT)], "meta/mid-c": ["ok"]}, clock)
    with pytest.raises(AmbiguousFailure):
        await r.complete("technical_analysis", MSG, idempotent=False)
    assert len(client.calls) == 1


async def test_time_sensitive_tasks_are_never_cached(clock):
    r, client, *_ = build_router({"meta/mid-b": ["one", "two"]}, clock)
    a = await r.complete("technical_analysis", MSG, cache_ttl=60)
    b = await r.complete("technical_analysis", MSG, cache_ttl=60)
    assert len(client.calls) == 2 and (a.text, b.text) == ("one", "two")


async def test_cache_works_for_non_time_sensitive_tasks(clock):
    r, client, *_ = build_router({"meta/light-a": ["hi", "again"]}, clock)
    a = await r.complete("discord_chat", MSG, cache_ttl=60)
    b = await r.complete("discord_chat", MSG, cache_ttl=60)
    assert len(client.calls) == 1 and a.text == b.text


async def test_unverified_json_mode_is_never_sent(clock):
    r, client, *_ = build_router({"meta/mid-b": ["ok"]}, clock)
    await r.complete("technical_analysis", MSG)
    assert client.calls[0]["json_mode"] is False
