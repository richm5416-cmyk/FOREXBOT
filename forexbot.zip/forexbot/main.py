"""Entry point.   python main.py            -> start the bot
                  python main.py --check    -> check settings + NVIDIA connection, then exit"""
from __future__ import annotations

import asyncio
import logging
import os
import sys

from dotenv import load_dotenv

from forexbot.ai.client import NvidiaClient
from forexbot.ai.credentials import CredentialManager
from forexbot.ai.health import HealthMonitor
from forexbot.ai.registry import load_registry
from forexbot.ai.router import AIRouter
from forexbot.config import Settings
from forexbot.discord_app.logic import AppContext
from forexbot.errors import AIError, ConfigError
from forexbot.forex.analyzer import ForexAnalyzer
from forexbot.forex.market_data import TwelveDataProvider
from forexbot.forex.risk import RiskManager
from forexbot.logging_config import setup_logging

log = logging.getLogger("forexbot")


def build(settings: Settings):
    registry = load_registry(settings.models_file)
    health = HealthMonitor()
    creds = CredentialManager(settings.nvidia_keys, settings.key_quota_scope)
    client = NvidiaClient(settings.nvidia_base_url)
    router = AIRouter(registry, health, creds, client, max_attempts=settings.max_attempts,
                      overall_deadline_s=settings.overall_deadline_s, max_concurrent=settings.max_concurrent,
                      request_timeout_cap_s=settings.request_timeout_s)
    if settings.routing_mode == "manual":
        if not settings.default_model:
            raise ConfigError("AI_ROUTING_MODE=manual needs AI_DEFAULT_MODEL to be set.")
        router.set_manual(settings.default_model)
    elif settings.default_model and settings.default_model not in registry.models:
        raise ConfigError(f"AI_DEFAULT_MODEL '{settings.default_model}' is not in models.yaml.")
    provider = TwelveDataProvider(settings.twelvedata_api_key, fallback=False)
    analyzer = ForexAnalyzer(provider, router, RiskManager(settings), settings)
    ctx = AppContext(settings, registry, router, health, creds, analyzer)
    return ctx, client, provider


async def verify_catalog(ctx: AppContext, client: NvidiaClient) -> None:
    """Switch off configured models that NVIDIA does not list for this key. Failure is non-fatal."""
    lease = ctx.creds.select()
    if lease is None:
        ctx.catalog_note = "Model catalog not checked (no usable key)."
        return
    try:
        available = await client.list_models(lease.secret)
    except AIError as e:
        ctx.catalog_note = f"Model catalog check skipped ({e.kind.value}); models are unverified."
        log.warning("catalog check failed: %s", e.kind.value)
        return
    missing = [m.id for m in ctx.registry.models.values() if m.enabled and m.id not in available]
    for mid in missing:
        ctx.registry.disable(mid, "not in NVIDIA catalog for your key")
        log.warning("model %s is not in the NVIDIA catalog for this key; disabled", mid)
    ok = sum(1 for m in ctx.registry.models.values() if m.enabled)
    ctx.catalog_note = f"Catalog check: {ok} model(s) confirmed available, {len(missing)} switched off."
    if ok == 0:
        log.error("No configured model is available. Edit models.yaml.")


SYNC_DELAY_S = 8  # let the bot's own startup sync finish first


async def force_sync(bot, tree) -> None:
    """Once the bot is online, push commands straight to every server it is in (they appear instantly)."""
    import discord
    for _ in range(180):  # wait up to 3 minutes for the bot to connect
        if bot.is_ready():
            break
        await asyncio.sleep(1)
    else:
        print("WARNING: bot never became ready, commands were not synced")
        return
    await asyncio.sleep(SYNC_DELAY_S)
    names = lambda cmds: sorted(c.name for c in cmds)
    try:
        local_guild = getattr(tree, "_guild_commands", None) or {}
        if local_guild and not tree.get_commands():
            # your bot registers commands per server already; just sync those servers again
            for gid in local_guild:
                synced = await tree.sync(guild=discord.Object(id=gid))
                print(f"Synced to server {gid}: {names(synced)}")
            return
        if not bot.guilds:
            synced = await tree.sync()
            print(f"Synced commands (global): {names(synced)}")
            return
        for g in bot.guilds:
            tree.copy_global_to(guild=g)
            synced = await tree.sync(guild=g)
            print(f"Synced to server '{g.name}' ({g.id}): {names(synced)}")
        # remove the older global copies so every command doesn't show up twice
        await bot.http.bulk_upsert_global_commands(bot.application_id, [])
        print("Removed old global copies of the commands (servers now hold them directly).")
    except Exception as e:
        log.exception("command sync failed")
        print(f"\nWARNING: command sync failed: {type(e).__name__}: {e}\n")


async def load_signals(bot, settings: Settings, ctx=None) -> None:
    """Add the /signal and /setbalance commands from signals.py (must sit next to main.py)."""
    # signals.py reads its NVIDIA keys from the environment; reuse the keys you already configured
    keys = [k if isinstance(k, str) else getattr(k, "secret", None) for k in settings.nvidia_keys]
    keys = [k for k in keys if k]
    if keys:
        os.environ.setdefault("NVIDIA_API_KEYS", ",".join(keys))
    try:
        import signals
        if ctx is not None:  # use the models from your models.yaml that passed the catalog check
            signals.MODEL_CANDIDATES = [m.id for m in ctx.registry.models.values() if m.enabled]
            print(f"/signal will use models: {signals.MODEL_CANDIDATES}")
        # a plain discord.Client keeps its command tree here if bot.tree isn't exposed
        tree = getattr(bot, "tree", None) or bot._connection._command_tree
        if tree is None:
            raise RuntimeError("could not find the bot's command tree (need to look at forexbot/discord_app/bot.py)")
        signals.register(tree)
        print("Loaded /signal and /setbalance commands.")
        bot._signals_sync_task = asyncio.create_task(force_sync(bot, tree))
    except Exception as e:  # keep the rest of the bot running even if signals.py has a problem
        log.exception("could not load signals.py")
        print(f"\nWARNING: /signal was NOT loaded: {type(e).__name__}: {e}\n")


async def run(check_only: bool) -> int:
    load_dotenv()
    try:
        settings = Settings.from_env(require_discord=not check_only)
        setup_logging(settings.log_level)
        ctx, client, provider = build(settings)
    except ConfigError as e:
        print(f"\nSETUP PROBLEM\n{e}\n")
        return 2
    try:
        await verify_catalog(ctx, client)
        print(ctx.catalog_note)
        if check_only:
            from forexbot.discord_app.logic import ai_test
            result = await ai_test(ctx)
            print(result)
            return 0 if "passed" in result else 1
        from forexbot.discord_app.bot import create_bot
        bot = create_bot(ctx)
        await load_signals(bot, settings, ctx)
        await bot.start(settings.discord_token)
    finally:
        await client.close()
        await provider.close()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(asyncio.run(run("--check" in sys.argv)))
    except KeyboardInterrupt:
        pass
