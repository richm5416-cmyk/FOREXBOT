"""Settings loaded from environment variables (.env) and validated at startup."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from urllib.parse import urlparse

from .errors import ConfigError

DEFAULT_BASE_URL = "https://integrate.api.nvidia.com/v1"
ALLOWED_AI_HOST = "integrate.api.nvidia.com"   # NVIDIA-only: refuse any other AI provider


@dataclass
class Settings:
    discord_token: str = ""
    nvidia_keys: list[str] = field(default_factory=list)
    nvidia_base_url: str = DEFAULT_BASE_URL
    routing_mode: str = "auto"
    default_model: str | None = None
    request_timeout_s: float = 30.0
    max_retries: int = 2
    overall_deadline_s: float = 45.0
    max_concurrent: int = 5
    key_quota_scope: str = "account"      # "account" = keys share one quota (safe default)
    models_file: str = "models.yaml"
    admin_user_ids: set[int] = field(default_factory=set)
    # trading / risk
    trading_mode: str = "paper"
    account_balance: float = 1000.0
    risk_per_trade_pct: float = 1.0
    max_daily_loss_pct: float = 3.0
    max_open_positions: int = 3
    min_risk_reward: float = 1.5
    max_spread_pips: float = 3.0
    duplicate_window_minutes: int = 240
    auto_paper_trade: bool = False
    # market data
    market_data_provider: str = "twelvedata"
    twelvedata_api_key: str = ""
    supported_pairs: list[str] = field(default_factory=lambda: ["EUR/USD", "GBP/USD", "USD/JPY"])
    state_file: str = "data/state.json"
    log_level: str = "INFO"

    @property
    def max_attempts(self) -> int:
        return self.max_retries + 1

    @classmethod
    def from_env(cls, env: dict | None = None, require_discord: bool = True) -> "Settings":
        env = dict(os.environ if env is None else env)
        errors: list[str] = []

        def num(name: str, default: float, lo: float | None = None, hi: float | None = None) -> float:
            raw = env.get(name, "").strip()
            if not raw:
                return default
            try:
                v = float(raw)
            except ValueError:
                errors.append(f"{name} must be a number (got '{raw}').")
                return default
            if (lo is not None and v < lo) or (hi is not None and v > hi):
                errors.append(f"{name} must be between {lo} and {hi} (got {v}).")
                return default
            return v

        keys: list[str] = []
        if env.get("NVIDIA_API_KEY", "").strip():
            keys.append(env["NVIDIA_API_KEY"].strip())
        numbered = sorted(
            (int(m.group(1)), v.strip()) for k, v in env.items()
            if (m := re.fullmatch(r"NVIDIA_API_KEY_(\d+)", k)) and v.strip()
        )
        keys += [v for _, v in numbered]
        keys = [k for i, k in enumerate(keys) if k not in keys[:i]]
        placeholders = [k for k in keys if k.startswith("replace_with")]
        if placeholders:
            errors.append("An NVIDIA key in .env is still the placeholder text. Paste your real key.")
            keys = [k for k in keys if not k.startswith("replace_with")]
        if not keys and not placeholders:
            errors.append("No NVIDIA API key found. Set NVIDIA_API_KEY_1 in your .env file.")

        token = env.get("DISCORD_BOT_TOKEN", "").strip()
        if require_discord and (not token or token.startswith("replace_with")):
            errors.append("DISCORD_BOT_TOKEN is missing. Paste your Discord bot token in .env.")

        base_url = env.get("NVIDIA_BASE_URL", DEFAULT_BASE_URL).strip().rstrip("/")
        parsed = urlparse(base_url)
        if parsed.scheme != "https" or parsed.hostname != ALLOWED_AI_HOST:
            errors.append(f"NVIDIA_BASE_URL must be https://{ALLOWED_AI_HOST}/... "
                          "(this bot only uses NVIDIA-hosted inference).")
            base_url = DEFAULT_BASE_URL

        mode = env.get("AI_ROUTING_MODE", "auto").strip().lower()
        if mode not in ("auto", "manual"):
            errors.append("AI_ROUTING_MODE must be 'auto' or 'manual'.")
            mode = "auto"
        scope = env.get("AI_KEY_QUOTA_SCOPE", "account").strip().lower()
        if scope not in ("account", "key"):
            errors.append("AI_KEY_QUOTA_SCOPE must be 'account' or 'key'.")
            scope = "account"

        trading_mode = env.get("TRADING_MODE", "paper").strip().lower()
        if trading_mode != "paper":
            errors.append("TRADING_MODE must be 'paper'. This bot has no live order execution; "
                          "it only produces analysis and paper-trading records.")
            trading_mode = "paper"

        admins: set[int] = set()
        for part in env.get("ADMIN_USER_IDS", "").replace(";", ",").split(","):
            part = part.strip()
            if part:
                if part.isdigit():
                    admins.add(int(part))
                else:
                    errors.append(f"ADMIN_USER_IDS contains '{part}', which is not a Discord user ID (digits only).")

        pairs = [p.strip().upper() for p in env.get("SUPPORTED_PAIRS", "EUR/USD,GBP/USD,USD/JPY").split(",") if p.strip()]
        for p in pairs:
            if not re.fullmatch(r"[A-Z]{3}/[A-Z]{3}", p):
                errors.append(f"SUPPORTED_PAIRS entry '{p}' must look like EUR/USD.")

        provider = env.get("MARKET_DATA_PROVIDER", "twelvedata").strip().lower()
        if provider not in ("twelvedata",):
            errors.append("MARKET_DATA_PROVIDER must be 'twelvedata' (the only built-in provider).")

        s = cls(
            discord_token=token,
            nvidia_keys=keys,
            nvidia_base_url=base_url,
            routing_mode=mode,
            default_model=env.get("AI_DEFAULT_MODEL", "").strip() or None,
            request_timeout_s=num("AI_REQUEST_TIMEOUT_SECONDS", 30, 1, 300),
            max_retries=int(num("AI_MAX_RETRIES", 2, 0, 10)),
            overall_deadline_s=num("AI_OVERALL_DEADLINE_SECONDS", 45, 2, 600),
            max_concurrent=int(num("AI_MAX_CONCURRENT_REQUESTS", 5, 1, 50)),
            key_quota_scope=scope,
            models_file=env.get("MODELS_FILE", "models.yaml").strip() or "models.yaml",
            admin_user_ids=admins,
            trading_mode=trading_mode,
            account_balance=num("ACCOUNT_BALANCE", 1000, 1),
            risk_per_trade_pct=num("RISK_PER_TRADE_PCT", 1.0, 0.01, 5),
            max_daily_loss_pct=num("MAX_DAILY_LOSS_PCT", 3.0, 0.1, 20),
            max_open_positions=int(num("MAX_OPEN_POSITIONS", 3, 1, 50)),
            min_risk_reward=num("MIN_RISK_REWARD", 1.5, 0.5, 20),
            max_spread_pips=num("MAX_SPREAD_PIPS", 3.0, 0, 100),
            duplicate_window_minutes=int(num("DUPLICATE_WINDOW_MINUTES", 240, 1, 10080)),
            auto_paper_trade=env.get("AUTO_PAPER_TRADE", "false").strip().lower() in ("1", "true", "yes"),
            market_data_provider=provider,
            twelvedata_api_key=env.get("TWELVEDATA_API_KEY", "").strip(),
            supported_pairs=pairs,
            state_file=env.get("STATE_FILE", "data/state.json").strip() or "data/state.json",
            log_level=env.get("LOG_LEVEL", "INFO").strip().upper(),
        )
        if errors:
            raise ConfigError("Settings problems:\n - " + "\n - ".join(errors))
        return s
