"""Command logic as plain functions that return text, so it can be tested without Discord."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from ..errors import AllModelsUnavailable, AmbiguousFailure, ConfigError

LIMIT = 1900


def clip(text: str, limit: int = LIMIT) -> str:
    return text if len(text) <= limit else text[: limit - 20] + "\n...(shortened)"


@dataclass
class AppContext:
    settings: object
    registry: object
    router: object
    health: object
    creds: object
    analyzer: object
    catalog_note: str = "Model catalog not checked yet."
    last_used: dict = field(default_factory=dict)


def is_admin(ctx: AppContext, user_id: int) -> bool:
    return user_id in ctx.settings.admin_user_ids


NOT_ADMIN = "This command is for bot administrators only."
NO_ADMINS = ("No administrators are configured. Add your Discord user ID to ADMIN_USER_IDS in .env "
             "and restart the bot.")


def check_admin(ctx: AppContext, user_id: int) -> str | None:
    if not ctx.settings.admin_user_ids:
        return NO_ADMINS
    return None if is_admin(ctx, user_id) else NOT_ADMIN


def rate_limited(ctx: AppContext, user_id: int, seconds: float = 15.0) -> float:
    """Returns seconds to wait (0 if allowed). Stops one user flooding the AI."""
    now = time.monotonic()
    wait = ctx.last_used.get(user_id, 0) + seconds - now
    if wait > 0:
        return wait
    ctx.last_used[user_id] = now
    return 0.0


# ------------------------------------------------------------------ /ai ...
def ai_status(ctx: AppContext) -> str:
    r = ctx.router
    mode = f"manual ({r.manual_model})" if r.mode == "manual" else "automatic"
    states: dict[str, int] = {}
    for m in ctx.registry.models.values():
        st = ctx.health.status(m.id).value
        states[st] = states.get(st, 0) + 1
    keys = ctx.creds.summary()
    key_ok = sum(1 for k in keys if k["status"] == "active")
    lines = [f"**AI router:** {mode}",
             "**Models:** " + ", ".join(f"{n} {s}" for s, n in sorted(states.items())),
             f"**API keys usable:** {key_ok}/{len(keys)}  (quota scope: {ctx.creds.quota_scope})",
             f"**Trading mode:** {ctx.settings.trading_mode} (analysis only, no live orders)",
             ctx.catalog_note]
    return "\n".join(lines)


def ai_models(ctx: AppContext) -> str:
    lines = ["**Models** (status / tier / tasks)"]
    for m in sorted(ctx.registry.models.values(), key=lambda x: (x.rank, x.priority)):
        st = "disabled" if not m.enabled else ctx.health.status(m.id).value
        flags = []
        if not m.listed_in_docs:
            flags.append("not in NVIDIA docs list")
        if m.supports_json is None:
            flags.append("JSON mode unverified")
        if not m.enabled and m.disabled_reason:
            flags.append(m.disabled_reason)
        lines.append(f"`{m.id}` - {st}, {m.tier}, {len(m.tasks)} tasks" + (f"  _({'; '.join(flags)})_" if flags else ""))
    return clip("\n".join(lines))


def ai_switch(ctx: AppContext, model_id: str) -> str:
    try:
        ctx.router.set_manual(model_id.strip())
    except ConfigError as e:
        return f"Could not switch: {e}"
    return (f"Preferred model set to `{model_id}`. If it fails, the router will still fall back to a healthy "
            "backup and tell you. Use /ai auto to go back to automatic routing.")


def ai_auto(ctx: AppContext) -> str:
    ctx.router.set_auto()
    return "Automatic routing is on."


async def ai_test(ctx: AppContext) -> str:
    try:
        res = await ctx.router.complete("discord_chat", [
            {"role": "user", "content": "Reply with the single word: OK"}], max_tokens=8, idempotent=True)
    except AllModelsUnavailable as e:
        return f"AI test FAILED ({e.kind}): {e.message}"
    except AmbiguousFailure:
        return "AI test failed (ambiguous error)."
    note = f" ({res.note})" if res.note else ""
    return f"AI test passed using `{res.model_id}` in {res.latency:.1f}s{note}."


def ai_stats(ctx: AppContext) -> str:
    st = ctx.router.stats()
    lines = [f"**Requests:** {st['total_requests']}   **Failovers:** {st['failovers']}"]
    for mid, s in st["per_model"].items():
        rate = "n/a" if s["success_rate"] is None else f"{int(s['success_rate'] * 100)}%"
        lat = "n/a" if s["avg_latency_s"] is None else f"{s['avg_latency_s']}s"
        lines.append(f"`{mid}`: {s['requests']} calls, success {rate}, avg {lat}")
    if len(lines) == 1:
        lines.append("No AI calls yet.")
    return clip("\n".join(lines))


def ai_cooldowns(ctx: AppContext) -> str:
    out = []
    for m in ctx.registry.models.values():
        rem = ctx.health.cooldown_remaining(m.id)
        if rem > 0:
            out.append(f"`{m.id}` - {ctx.health.status(m.id).value}, retry in about {int(rem)}s")
        elif not m.enabled:
            out.append(f"`{m.id}` - disabled ({m.disabled_reason or 'turned off'})")
    for k in ctx.creds.summary():
        if k["status"] != "active":
            out.append(f"{k['label']} - {k['status']}")
    return "\n".join(out) if out else "Nothing is on cooldown."


def ai_history(ctx: AppContext) -> str:
    rows = ctx.router.history(10)
    if not rows:
        return "No routing history yet."
    lines = []
    for h in reversed(rows):
        fails = [o for _, o in h["attempts"] if o != "ok"]
        lines.append(f"{h['task']} -> `{h['model'] or 'none'}` ({h['outcome']}, {h['duration_s']}s)"
                     + (f" failures: {', '.join(fails)}" if fails else ""))
    return clip("\n".join(lines))


# ---------------------------------------------------------------- user commands
def format_analysis(r) -> str:
    head = f"**{r.pair} {r.timeframe}** - **{r.signal}**"
    lines = [head]
    if r.data_time:
        lines.append(f"Data: {r.data_source}, latest candle {time.strftime('%Y-%m-%d %H:%M', time.gmtime(r.data_time))} UTC")
    v = r.validated
    if v and r.signal in ("BUY", "SELL"):
        lines += [f"Entry {v.entry}  |  Stop {v.stop_loss}  |  Targets {', '.join(str(t) for t in v.take_profits)}",
                  f"Risk/Reward {v.risk_reward}  |  Bias {v.bias}"]
        if r.risk and r.risk.approved:
            lines.append(f"Paper position size: {r.risk.lots} lots (risk ${r.risk.risk_amount:.2f})")
        elif r.risk:
            lines.append("**Blocked by risk controls:** " + " ".join(r.risk.reasons))
        if v.supporting:
            lines.append("Why: " + "; ".join(v.supporting[:3]))
        if v.contradicting:
            lines.append("Against: " + "; ".join(v.contradicting[:2]))
        if v.invalidation:
            lines.append("Invalid if: " + "; ".join(v.invalidation[:2]))
        lines.append(f"Model: `{r.model_id}`")
    else:
        for reason in r.reasons[:4]:
            lines.append("- " + reason)
    lines.append("_Analysis only - not financial advice. No outcome is guaranteed._")
    return clip("\n".join(lines))


async def analyze_cmd(ctx: AppContext, user_id: int, pair: str, timeframe: str) -> str:
    wait = rate_limited(ctx, user_id)
    if wait:
        return f"Please wait {int(wait) + 1}s before the next request."
    return format_analysis(await ctx.analyzer.analyze(pair, timeframe))


async def summary_cmd(ctx: AppContext, user_id: int, pair: str, timeframe: str) -> str:
    wait = rate_limited(ctx, user_id)
    if wait:
        return f"Please wait {int(wait) + 1}s before the next request."
    return clip(await ctx.analyzer.quick_summary(pair, timeframe))


async def ask_cmd(ctx: AppContext, user_id: int, question: str) -> str:
    wait = rate_limited(ctx, user_id)
    if wait:
        return f"Please wait {int(wait) + 1}s before the next request."
    msgs = [{"role": "system", "content": "You are a helpful assistant in a forex Discord server. You have no "
             "live market data or news. Never invent prices or events. Do not give guaranteed-profit claims. "
             "Keep answers short."},
            {"role": "user", "content": question[:1500]}]
    try:
        return clip((await ctx.router.complete("discord_chat", msgs)).text)
    except (AllModelsUnavailable, AmbiguousFailure):
        return "The AI is unavailable right now. Please try again in a minute."
