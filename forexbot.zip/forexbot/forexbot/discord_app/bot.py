"""Thin discord.py layer. All real logic lives in logic.py."""
from __future__ import annotations

import io
import logging

import discord
from discord import app_commands

from ..forex.charts import ChartError, build_chart
from . import logic as L

log = logging.getLogger("forexbot.discord")


def create_bot(ctx: L.AppContext) -> discord.Client:
    intents = discord.Intents.default()           # slash commands only: no message-content intent needed
    client = discord.Client(intents=intents)
    tree = app_commands.CommandTree(client)
    ai = app_commands.Group(name="ai", description="AI router administration (admins only)")

    async def admin_gate(interaction: discord.Interaction) -> bool:
        problem = L.check_admin(ctx, interaction.user.id)
        if problem:
            await interaction.response.send_message(problem, ephemeral=True)
            return False
        return True

    @ai.command(name="status", description="Router mode and system health")
    async def ai_status(interaction: discord.Interaction):
        if await admin_gate(interaction):
            await interaction.response.send_message(L.ai_status(ctx), ephemeral=True)

    @ai.command(name="models", description="Enabled models and verified capabilities")
    async def ai_models(interaction: discord.Interaction):
        if await admin_gate(interaction):
            await interaction.response.send_message(L.ai_models(ctx), ephemeral=True)

    @ai.command(name="switch", description="Prefer a specific model")
    @app_commands.describe(model="Exact model ID from /ai models")
    async def ai_switch(interaction: discord.Interaction, model: str):
        if await admin_gate(interaction):
            await interaction.response.send_message(L.ai_switch(ctx, model), ephemeral=True)

    @ai_switch.autocomplete("model")
    async def model_autocomplete(interaction: discord.Interaction, current: str):
        ids = [m.id for m in ctx.registry.models.values() if m.enabled and current.lower() in m.id.lower()]
        return [app_commands.Choice(name=i[:100], value=i) for i in ids[:25]]

    @ai.command(name="auto", description="Turn on automatic routing")
    async def ai_auto(interaction: discord.Interaction):
        if await admin_gate(interaction):
            await interaction.response.send_message(L.ai_auto(ctx), ephemeral=True)

    @ai.command(name="test", description="Run a small safe connectivity test")
    async def ai_test(interaction: discord.Interaction):
        if await admin_gate(interaction):
            await interaction.response.defer(ephemeral=True, thinking=True)
            await interaction.followup.send(await L.ai_test(ctx), ephemeral=True)

    @ai.command(name="stats", description="Request counts, latency, success rate, failovers")
    async def ai_stats(interaction: discord.Interaction):
        if await admin_gate(interaction):
            await interaction.response.send_message(L.ai_stats(ctx), ephemeral=True)

    @ai.command(name="cooldowns", description="Unavailable models and retry times")
    async def ai_cooldowns(interaction: discord.Interaction):
        if await admin_gate(interaction):
            await interaction.response.send_message(L.ai_cooldowns(ctx), ephemeral=True)

    @ai.command(name="history", description="Recent routing decisions and failures")
    async def ai_history(interaction: discord.Interaction):
        if await admin_gate(interaction):
            await interaction.response.send_message(L.ai_history(ctx), ephemeral=True)

    tree.add_command(ai)

    @tree.command(name="analyze", description="AI-assisted forex analysis (analysis only, not advice)")
    @app_commands.describe(pair="e.g. EUR/USD", timeframe="M15, M30, H1, H4 or D1")
    async def analyze(interaction: discord.Interaction, pair: str, timeframe: str = "H1"):
        await interaction.response.defer(thinking=True)
        await interaction.followup.send(await L.analyze_cmd(ctx, interaction.user.id, pair, timeframe))

    @tree.command(name="summary", description="Quick neutral market summary")
    async def summary(interaction: discord.Interaction, pair: str, timeframe: str = "H1"):
        await interaction.response.defer(thinking=True)
        await interaction.followup.send(await L.summary_cmd(ctx, interaction.user.id, pair, timeframe))

    @tree.command(name="ask", description="Ask the AI a question")
    async def ask(interaction: discord.Interaction, question: str):
        await interaction.response.defer(thinking=True)
        await interaction.followup.send(await L.ask_cmd(ctx, interaction.user.id, question))

    # ---- NEW: candlestick chart for any currency pair -------------------------------------------
    @tree.command(name="chart", description="Candlestick chart for any currency pair")
    @app_commands.describe(pair="e.g. EUR/USD or GBP/JPY", timeframe="M5, M15, M30, H1, H4, D1 or W1")
    @app_commands.checks.cooldown(1, 8.0)         # one chart per user every 8 seconds
    async def chart(interaction: discord.Interaction, pair: str, timeframe: str = "H1"):
        await interaction.response.defer(thinking=True)
        try:
            result = await build_chart(pair, timeframe)
        except ChartError as e:
            await interaction.followup.send(str(e), ephemeral=True)
            return
        embed = discord.Embed(
            title=f"{result.pair[:3]}/{result.pair[3:]} - {result.timeframe}",
            url=result.tradingview_url,           # clicking the title opens TradingView
            description=f"[Open in TradingView]({result.tradingview_url})",
            color=0x2B6CB0,
        )
        embed.set_image(url="attachment://chart.png")
        embed.set_footer(text=f"Last close {result.last_close:.{result.decimals}f} | "
                              "Data: Yahoo Finance (may be delayed) | Not financial advice")
        await interaction.followup.send(
            embed=embed, file=discord.File(io.BytesIO(result.png), filename="chart.png"))
    # ---------------------------------------------------------------------------------------------

    @tree.error
    async def on_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
        log.error("command error: %s", type(error).__name__)       # no stack trace shown to users
        if isinstance(error, app_commands.CommandOnCooldown):
            msg = f"Slow down, try again in {error.retry_after:.0f}s."
        else:
            msg = "Something went wrong. Please try again."
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)

    @client.event
    async def on_ready():
        await tree.sync()
        log.info("Bot online as %s", client.user)

    return client