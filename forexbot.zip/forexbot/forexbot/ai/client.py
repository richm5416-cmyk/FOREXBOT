"""Async client for NVIDIA's OpenAI-compatible chat-completions endpoint."""
from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from typing import Mapping

import aiohttp

from ..config import DEFAULT_BASE_URL
from ..errors import AIError, AIErrorKind
from ..logging_config import redact

_THINK = re.compile(r"<think>.*?</think>", re.S)


@dataclass
class ChatResult:
    text: str
    model: str
    latency: float = 0.0
    usage: dict = field(default_factory=dict)
    finish_reason: str | None = None


def _retry_after(headers: Mapping) -> float | None:
    raw = None
    for k, v in headers.items():
        if k.lower() == "retry-after":
            raw = v
            break
    try:
        return float(raw) if raw is not None else None
    except (TypeError, ValueError):
        return None          # HTTP-date form: ignored, default cooldown is used


def parse_chat_response(status: int, headers: Mapping, body: str, model: str = "") -> ChatResult:
    """Pure function: turn an HTTP response into a ChatResult or a classified AIError."""
    snippet = redact(body[:200].replace("\n", " "))
    if status == 429:
        raise AIError(AIErrorKind.RATE_LIMIT, "rate limited", status, _retry_after(headers))
    if status in (401, 403):
        raise AIError(AIErrorKind.AUTH, f"HTTP {status} (key rejected or not allowed for this model)", status)
    if status == 404:
        raise AIError(AIErrorKind.NOT_FOUND, "model or endpoint not found", status)
    if status == 408:
        raise AIError(AIErrorKind.TIMEOUT, "server reported request timeout", status)
    if status in (400, 422):
        raise AIError(AIErrorKind.BAD_REQUEST, f"HTTP {status}: {snippet}", status)
    if status >= 500:
        raise AIError(AIErrorKind.SERVER, f"HTTP {status}", status, _retry_after(headers))
    if status != 200:
        raise AIError(AIErrorKind.BAD_REQUEST, f"unexpected HTTP {status}: {snippet}", status)
    try:
        data = json.loads(body)
    except (ValueError, TypeError):
        raise AIError(AIErrorKind.MALFORMED, "response was not valid JSON", status)
    try:
        choice = data["choices"][0]
        content = choice["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise AIError(AIErrorKind.MALFORMED, "response had an unexpected structure", status)
    if content is None or not isinstance(content, str):
        raise AIError(AIErrorKind.EMPTY, "model returned no text", status)
    text = _THINK.sub("", content).strip()
    if not text:
        raise AIError(AIErrorKind.EMPTY, "model returned an empty reply", status)
    usage = data.get("usage") if isinstance(data.get("usage"), dict) else {}
    return ChatResult(text=text, model=model, usage=usage, finish_reason=choice.get("finish_reason"))


class NvidiaClient:
    def __init__(self, base_url: str = DEFAULT_BASE_URL):
        self.base_url = base_url.rstrip("/")
        self._session: aiohttp.ClientSession | None = None

    async def _sess(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(connector=aiohttp.TCPConnector(limit=20, ttl_dns_cache=300))
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def chat(self, *, model: str, messages: list[dict], api_key: str, max_tokens: int,
                   temperature: float, timeout: float, json_mode: bool = False) -> ChatResult:
        payload: dict = {"model": model, "messages": messages, "max_tokens": max_tokens,
                         "temperature": temperature, "stream": False}
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json",
                   "Content-Type": "application/json"}
        t0 = time.monotonic()
        try:
            sess = await self._sess()
            async with sess.post(f"{self.base_url}/chat/completions", json=payload, headers=headers,
                                 timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                body = await resp.text()
                result = parse_chat_response(resp.status, resp.headers, body, model)
        except AIError:
            raise
        except asyncio.TimeoutError:
            raise AIError(AIErrorKind.TIMEOUT, f"no answer within {timeout:.0f}s")
        except (aiohttp.ClientConnectionError, aiohttp.ClientError, OSError) as e:
            raise AIError(AIErrorKind.NETWORK, f"connection problem ({type(e).__name__})")
        result.latency = time.monotonic() - t0
        return result

    async def list_models(self, api_key: str, timeout: float = 15.0) -> set[str]:
        """Ask NVIDIA which model IDs this key can see (GET /v1/models)."""
        headers = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
        try:
            sess = await self._sess()
            async with sess.get(f"{self.base_url}/models", headers=headers,
                                timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
                body = await resp.text()
                if resp.status in (401, 403):
                    raise AIError(AIErrorKind.AUTH, f"HTTP {resp.status}", resp.status)
                if resp.status != 200:
                    raise AIError(AIErrorKind.SERVER, f"HTTP {resp.status}", resp.status)
        except AIError:
            raise
        except asyncio.TimeoutError:
            raise AIError(AIErrorKind.TIMEOUT, "model list request timed out")
        except (aiohttp.ClientError, OSError) as e:
            raise AIError(AIErrorKind.NETWORK, f"connection problem ({type(e).__name__})")
        try:
            return {m["id"] for m in json.loads(body)["data"] if isinstance(m, dict) and "id" in m}
        except (ValueError, KeyError, TypeError):
            raise AIError(AIErrorKind.MALFORMED, "model list had an unexpected structure")
