"""Model registry: which NVIDIA-hosted models are enabled and what each is good for."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

from ..errors import ConfigError

TIER_RANK = {"light": 0, "standard": 1, "heavy": 2}
KNOWN_TASKS = {
    "quick_summary", "technical_analysis", "fundamental_analysis", "multi_timeframe",
    "signal_validation", "trade_explanation", "discord_chat", "coding_debug", "complex_reasoning",
}


@dataclass
class ModelSpec:
    id: str
    tier: str = "standard"
    priority: int = 100
    tasks: frozenset = frozenset()
    expected_latency_s: float = 5.0
    timeout_s: float = 30.0
    max_output_tokens: int = 1024
    context_length: int | None = None
    supports_json: bool | None = None      # None = unverified -> never assumed
    listed_in_docs: bool = False
    enabled: bool = True
    disabled_reason: str = ""
    notes: str = ""

    @property
    def rank(self) -> int:
        return TIER_RANK[self.tier]


@dataclass
class RoutingProfile:
    task: str
    min_tier: str = "light"
    preferred_tier: str = "light"
    max_tokens: int = 500
    time_sensitive: bool = False
    json: bool = False
    temperature: float = 0.2


@dataclass
class ModelRegistry:
    models: dict[str, ModelSpec] = field(default_factory=dict)
    profiles: dict[str, RoutingProfile] = field(default_factory=dict)
    default_model: str | None = None

    def profile(self, task: str) -> RoutingProfile:
        if task not in self.profiles:
            raise ConfigError(f"Unknown task '{task}'. Known tasks: {', '.join(sorted(self.profiles))}")
        return self.profiles[task]

    def candidates(self, task: str) -> list[ModelSpec]:
        prof = self.profile(task)
        return [m for m in self.models.values()
                if m.enabled and task in m.tasks and m.rank >= TIER_RANK[prof.min_tier]]

    def disable(self, model_id: str, reason: str) -> None:
        if model_id in self.models:
            self.models[model_id].enabled = False
            self.models[model_id].disabled_reason = reason


def _num(entry: dict, key: str, default, kind=float, lo=None):
    val = entry.get(key, default)
    try:
        out = kind(val)
    except (TypeError, ValueError):
        raise ConfigError(f"models.yaml: model '{entry.get('id')}': '{key}' must be a number (got {val!r}).")
    if lo is not None and out < lo:
        raise ConfigError(f"models.yaml: model '{entry.get('id')}': '{key}' must be >= {lo}.")
    return out


def registry_from_dict(data: dict) -> ModelRegistry:
    if not isinstance(data, dict):
        raise ConfigError("models.yaml must contain a mapping with 'models' and 'routing'.")
    reg = ModelRegistry(default_model=data.get("default_model"))

    for prof_task, p in (data.get("routing") or {}).items():
        if prof_task not in KNOWN_TASKS:
            raise ConfigError(f"models.yaml: routing task '{prof_task}' is not a known task.")
        p = p or {}
        for k in ("min_tier", "preferred_tier"):
            if p.get(k, "light") not in TIER_RANK:
                raise ConfigError(f"models.yaml: routing '{prof_task}': {k} must be light, standard or heavy.")
        reg.profiles[prof_task] = RoutingProfile(
            task=prof_task, min_tier=p.get("min_tier", "light"),
            preferred_tier=p.get("preferred_tier", "light"),
            max_tokens=int(p.get("max_tokens", 500)),
            time_sensitive=bool(p.get("time_sensitive", False)),
            json=bool(p.get("json", False)),
            temperature=float(p.get("temperature", 0.2)),
        )

    for entry in data.get("models") or []:
        mid = (entry or {}).get("id")
        if not mid or not isinstance(mid, str) or "/" not in mid:
            raise ConfigError(f"models.yaml: every model needs an 'id' like 'publisher/model-name' (got {mid!r}).")
        if mid in reg.models:
            raise ConfigError(f"models.yaml: model '{mid}' is listed twice.")
        tier = entry.get("tier", "standard")
        if tier not in TIER_RANK:
            raise ConfigError(f"models.yaml: model '{mid}': tier must be light, standard or heavy (got {tier!r}).")
        tasks = entry.get("tasks") or []
        bad = [t for t in tasks if t not in KNOWN_TASKS]
        if bad:
            raise ConfigError(f"models.yaml: model '{mid}' has unknown task(s): {', '.join(bad)}")
        sj = entry.get("supports_json")
        if sj is not None and not isinstance(sj, bool):
            raise ConfigError(f"models.yaml: model '{mid}': supports_json must be true, false or empty.")
        cl = entry.get("context_length")
        reg.models[mid] = ModelSpec(
            id=mid, tier=tier, priority=_num(entry, "priority", 100, int),
            tasks=frozenset(tasks),
            expected_latency_s=_num(entry, "expected_latency_s", 5.0, float, 0),
            timeout_s=_num(entry, "timeout_s", 30.0, float, 1),
            max_output_tokens=_num(entry, "max_output_tokens", 1024, int, 1),
            context_length=int(cl) if cl else None,
            supports_json=sj, listed_in_docs=bool(entry.get("listed_in_docs", False)),
            enabled=bool(entry.get("enabled", True)), notes=str(entry.get("notes", "")),
        )

    if not reg.models:
        raise ConfigError("models.yaml has no models. Add at least one NVIDIA-hosted model.")
    if reg.default_model and reg.default_model not in reg.models:
        raise ConfigError(f"models.yaml: default_model '{reg.default_model}' is not in the models list.")
    return reg


def load_registry(path: str | Path) -> ModelRegistry:
    p = Path(path)
    if not p.exists():
        raise ConfigError(f"Models file not found: {p}")
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        raise ConfigError(f"models.yaml is not valid YAML: {e}")
    return registry_from_dict(data)
