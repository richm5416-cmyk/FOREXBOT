"""API-key manager. Keys are never printed, logged, or returned in messages."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from ..logging_config import register_secret


@dataclass(frozen=True)
class KeyLease:
    label: str
    secret: str = field(repr=False)

    def __repr__(self) -> str:          # never show the secret
        return f"KeyLease(label={self.label!r})"


@dataclass
class _Key:
    label: str
    secret: str = field(repr=False)
    auth_failed: bool = False
    disabled: bool = False
    cooldown_until: float = 0.0
    uses: int = 0
    rate_limit_hits: int = 0


class CredentialManager:
    """
    quota_scope:
      "account" (default) - all keys share one quota. A 429 never triggers key switching.
      "key"               - each key has its own quota. A 429 may be retried on another key.
    Having several keys is optional; one key works fine.
    """

    def __init__(self, keys: list[str], quota_scope: str = "account", clock=time.monotonic):
        self.quota_scope = quota_scope
        self._clock = clock
        self._keys = [_Key(label=f"key{i + 1}", secret=k) for i, k in enumerate(keys)]
        for k in keys:
            register_secret(k)

    @property
    def can_rotate_on_rate_limit(self) -> bool:
        return self.quota_scope == "key"

    def _usable(self, k: _Key) -> bool:
        return not (k.auth_failed or k.disabled) and self._clock() >= k.cooldown_until

    def select(self, exclude: set[str] | None = None) -> KeyLease | None:
        exclude = exclude or set()
        usable = [k for k in self._keys if k.label not in exclude and self._usable(k)]
        if not usable:
            return None
        k = min(usable, key=lambda x: x.uses)          # spread use evenly
        k.uses += 1
        return KeyLease(label=k.label, secret=k.secret)

    def has_usable(self, exclude: set[str] | None = None) -> bool:
        exclude = exclude or set()
        return any(k.label not in exclude and self._usable(k) for k in self._keys)

    def report_rate_limit(self, label: str, retry_after: float | None) -> None:
        k = self._find(label)
        if k:
            k.rate_limit_hits += 1
            k.cooldown_until = self._clock() + min(max(retry_after or 30.0, 1.0), 600.0)

    def report_auth_failure(self, label: str) -> None:
        k = self._find(label)
        if k:
            k.auth_failed = True

    def report_success(self, label: str) -> None:
        k = self._find(label)
        if k:
            k.cooldown_until = 0.0

    def disable(self, label: str) -> None:
        k = self._find(label)
        if k:
            k.disabled = True

    def replace(self, label: str, new_secret: str) -> bool:
        k = self._find(label)
        if not k:
            return False
        k.secret, k.auth_failed, k.disabled, k.cooldown_until = new_secret, False, False, 0.0
        register_secret(new_secret)
        return True

    def _find(self, label: str) -> _Key | None:
        return next((k for k in self._keys if k.label == label), None)

    def summary(self) -> list[dict]:
        out = []
        for k in self._keys:
            if k.auth_failed:
                st = "authentication_failed"
            elif k.disabled:
                st = "disabled"
            elif self._clock() < k.cooldown_until:
                st = "cooling_down"
            else:
                st = "active"
            out.append({"label": k.label, "status": st, "rate_limit_hits": k.rate_limit_hits})
        return out
