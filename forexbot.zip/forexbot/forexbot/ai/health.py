"""Model health tracking and circuit breaker."""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum

from ..errors import AIErrorKind


class Status(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    RATE_LIMITED = "rate_limited"
    AUTH_FAILURE = "authentication_failure"
    UNAVAILABLE = "temporarily_unavailable"
    DISABLED = "disabled"
    UNKNOWN = "unknown"


@dataclass
class ModelHealth:
    consecutive_failures: int = 0
    cooldown_until: float = 0.0
    cooldown_kind: AIErrorKind | None = None
    ewma_latency: float | None = None
    successes: int = 0
    failures: int = 0
    recent: deque = field(default_factory=lambda: deque(maxlen=20))   # True = success
    last_success_wall: float | None = None
    last_error_kind: AIErrorKind | None = None
    disabled_reason: str = ""


class HealthMonitor:
    def __init__(self, clock=time.monotonic, wall=time.time, failure_threshold: int = 3,
                 base_cooldown: float = 15.0, max_cooldown: float = 300.0,
                 rate_limit_default: float = 30.0, not_found_cooldown: float = 600.0,
                 bad_request_cooldown: float = 60.0):
        self._clock, self._wall = clock, wall
        self.failure_threshold = failure_threshold
        self.base_cooldown, self.max_cooldown = base_cooldown, max_cooldown
        self.rate_limit_default = rate_limit_default
        self.not_found_cooldown = not_found_cooldown
        self.bad_request_cooldown = bad_request_cooldown
        self._h: dict[str, ModelHealth] = {}

    def _get(self, model: str) -> ModelHealth:
        return self._h.setdefault(model, ModelHealth())

    def is_available(self, model: str) -> bool:
        h = self._get(model)
        if h.disabled_reason:
            return False
        return self._clock() >= h.cooldown_until

    def cooldown_remaining(self, model: str) -> float:
        h = self._get(model)
        return max(0.0, h.cooldown_until - self._clock())

    def record_success(self, model: str, latency: float) -> None:
        h = self._get(model)
        h.successes += 1
        h.consecutive_failures = 0
        h.cooldown_until = 0.0
        h.cooldown_kind = None
        h.recent.append(True)
        h.ewma_latency = latency if h.ewma_latency is None else 0.7 * h.ewma_latency + 0.3 * latency
        h.last_success_wall = self._wall()

    def record_failure(self, model: str, kind: AIErrorKind, retry_after: float | None = None) -> None:
        h = self._get(model)
        h.failures += 1
        h.recent.append(False)
        h.last_error_kind = kind
        now = self._clock()
        if kind == AIErrorKind.RATE_LIMIT:
            wait = retry_after if retry_after and retry_after > 0 else self.rate_limit_default
            h.cooldown_until, h.cooldown_kind = now + min(wait, 600.0), kind
            return
        if kind == AIErrorKind.NOT_FOUND:
            h.cooldown_until, h.cooldown_kind = now + self.not_found_cooldown, kind
            return
        if kind == AIErrorKind.BAD_REQUEST:
            h.cooldown_until, h.cooldown_kind = now + self.bad_request_cooldown, kind
            return
        h.consecutive_failures += 1
        if h.consecutive_failures >= self.failure_threshold:      # circuit opens
            over = h.consecutive_failures - self.failure_threshold
            wait = min(self.max_cooldown, self.base_cooldown * (2 ** over))
            h.cooldown_until, h.cooldown_kind = now + wait, kind

    def disable(self, model: str, reason: str) -> None:
        self._get(model).disabled_reason = reason

    def enable(self, model: str) -> None:
        h = self._get(model)
        h.disabled_reason = ""
        h.cooldown_until = 0.0
        h.consecutive_failures = 0

    def failure_rate(self, model: str) -> float:
        h = self._get(model)
        if len(h.recent) < 3:
            return 0.0
        return sum(1 for ok in h.recent if not ok) / len(h.recent)

    def avg_latency(self, model: str) -> float | None:
        return self._get(model).ewma_latency

    def status(self, model: str) -> Status:
        h = self._get(model)
        if h.disabled_reason:
            return Status.DISABLED
        if self._clock() < h.cooldown_until:
            return {AIErrorKind.RATE_LIMIT: Status.RATE_LIMITED,
                    AIErrorKind.AUTH: Status.AUTH_FAILURE}.get(h.cooldown_kind, Status.UNAVAILABLE)
        if h.consecutive_failures > 0 or self.failure_rate(model) > 0.3:
            return Status.DEGRADED
        return Status.HEALTHY if h.successes > 0 else Status.UNKNOWN

    def detail(self, model: str) -> dict:
        h = self._get(model)
        return {
            "status": self.status(model).value,
            "successes": h.successes, "failures": h.failures,
            "failure_rate": round(self.failure_rate(model), 2),
            "avg_latency_s": None if h.ewma_latency is None else round(h.ewma_latency, 2),
            "cooldown_remaining_s": round(self.cooldown_remaining(model)),
            "last_error": h.last_error_kind.value if h.last_error_kind else None,
            "last_success_epoch": h.last_success_wall,
        }
