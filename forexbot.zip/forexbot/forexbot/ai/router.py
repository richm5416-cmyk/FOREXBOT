"""
The router: picks the best AVAILABLE model for a task, fails over quickly,
and never lets a failure turn into an invented answer.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import random
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field

from ..errors import (AMBIGUOUS_KINDS, TRANSIENT_KINDS, AIError, AIErrorKind, AllModelsUnavailable,
                      AmbiguousFailure, ConfigError)
from ..logging_config import log_event
from .credentials import CredentialManager
from .health import HealthMonitor
from .registry import ModelRegistry, ModelSpec, TIER_RANK

log = logging.getLogger("forexbot.router")


@dataclass
class Attempt:
    model: str
    key: str
    outcome: str            # "ok" or an AIErrorKind value
    seconds: float


@dataclass
class RouteResult:
    text: str
    model_id: str
    key_label: str
    task: str
    attempts: list[Attempt] = field(default_factory=list)
    failed_over: bool = False
    note: str = ""
    latency: float = 0.0
    usage: dict = field(default_factory=dict)


class _State:
    def __init__(self):
        self.n = 0
        self.attempts: list[Attempt] = []


class AIRouter:
    def __init__(self, registry: ModelRegistry, health: HealthMonitor, creds: CredentialManager, client,
                 *, max_attempts: int = 3, overall_deadline_s: float = 45.0, max_concurrent: int = 5,
                 request_timeout_cap_s: float = 60.0, clock=time.monotonic, wall=time.time,
                 sleep=asyncio.sleep, rng=random.random, backoff_base: float = 0.5, backoff_max: float = 8.0):
        self.registry, self.health, self.creds, self.client = registry, health, creds, client
        self.max_attempts = max(1, max_attempts)
        self.overall_deadline_s = overall_deadline_s
        self.request_timeout_cap_s = request_timeout_cap_s
        self._clock, self._wall, self._sleep, self._rng = clock, wall, sleep, rng
        self.backoff_base, self.backoff_max = backoff_base, backoff_max
        self._sem = asyncio.Semaphore(max_concurrent)
        self.mode = "auto"
        self.manual_model: str | None = None
        self._inflight: dict[str, asyncio.Future] = {}
        self._cache: dict[str, tuple[float, RouteResult]] = {}
        self._history: deque = deque(maxlen=200)
        self._stats = defaultdict(lambda: {"requests": 0, "ok": 0, "fail": 0, "latency_sum": 0.0})
        self.failovers = 0
        self.total_requests = 0

    # ------------------------------------------------------------------ mode
    def set_manual(self, model_id: str) -> None:
        spec = self.registry.models.get(model_id)
        if not spec:
            raise ConfigError(f"'{model_id}' is not in models.yaml.")
        if not spec.enabled:
            raise ConfigError(f"'{model_id}' is disabled ({spec.disabled_reason or 'turned off'}).")
        self.mode, self.manual_model = "manual", model_id

    def set_auto(self) -> None:
        self.mode, self.manual_model = "auto", None

    # -------------------------------------------------------------- planning
    def plan(self, task: str, est_tokens: int = 0) -> list[ModelSpec]:
        """Ordered list of models to try. Pure decision logic, no network."""
        prof = self.registry.profile(task)
        pref = TIER_RANK[prof.preferred_tier]
        cands = []
        for m in self.registry.candidates(task):
            if not self.health.is_available(m.id):
                continue
            if m.context_length and est_tokens > m.context_length:
                continue
            cands.append(m)

        def score(m: ModelSpec):
            penalty = 50 * self.health.failure_rate(m.id)
            lat = self.health.avg_latency(m.id) or m.expected_latency_s
            return (abs(m.rank - pref), m.priority + penalty, lat)

        cands.sort(key=score)
        if self.mode == "manual" and self.manual_model:
            spec = self.registry.models.get(self.manual_model)
            if spec and spec.enabled and self.health.is_available(spec.id):
                cands = [spec] + [m for m in cands if m.id != spec.id]
        return cands

    # ------------------------------------------------------------ public API
    async def complete(self, task: str, messages: list[dict], *, max_tokens: int | None = None,
                       idempotent: bool = True, cache_ttl: float = 0.0) -> RouteResult:
        """
        idempotent=False means "this request must not be repeated if it might already have had an
        effect": on an ambiguous failure the router raises AmbiguousFailure instead of retrying.
        """
        prof = self.registry.profile(task)
        key = hashlib.sha256(json.dumps([task, messages, max_tokens], sort_keys=True).encode()).hexdigest()
        if cache_ttl > 0 and not prof.time_sensitive:
            hit = self._cache.get(key)
            if hit and self._clock() - hit[0] < cache_ttl:
                return hit[1]
        if idempotent and key in self._inflight:                    # identical request already running
            return await asyncio.shield(self._inflight[key])
        fut = asyncio.ensure_future(self._run(task, messages, prof, max_tokens, idempotent))
        if idempotent:
            self._inflight[key] = fut
        try:
            res = await asyncio.shield(fut)
        finally:
            if self._inflight.get(key) is fut:
                self._inflight.pop(key, None)
        if cache_ttl > 0 and not prof.time_sensitive:
            self._cache[key] = (self._clock(), res)
        return res

    # --------------------------------------------------------------- engine
    async def _run(self, task, messages, prof, max_tokens, idempotent) -> RouteResult:
        async with self._sem:
            started = self._clock()
            deadline = started + self.overall_deadline_s
            est = sum(len(str(m.get("content", ""))) for m in messages) // 3 + (max_tokens or prof.max_tokens)
            order = self.plan(task, est)
            state = _State()
            self.total_requests += 1
            if not order:
                self._finish(task, None, state, started, "no_model")
                raise AllModelsUnavailable("no_model", "No enabled model is currently available for this task.")
            preferred = order[0].id
            for idx, spec in enumerate(order):
                if state.n >= self.max_attempts or self._clock() >= deadline:
                    break
                try:
                    res = await self._try_model(spec, idx == len(order) - 1, task, messages, prof,
                                                max_tokens, idempotent, state, deadline)
                except (AllModelsUnavailable, AmbiguousFailure) as e:
                    self._finish(task, None, state, started, type(e).__name__)
                    if isinstance(e, AllModelsUnavailable):
                        e.attempts = state.attempts
                    raise
                if res is not None:
                    res.attempts = state.attempts
                    res.latency = self._clock() - started
                    res.failed_over = res.model_id != preferred or len(state.attempts) > 1
                    if res.failed_over:
                        self.failovers += 1
                        res.note = f"Switched from {preferred} to {res.model_id}" if res.model_id != preferred \
                            else "Recovered after a retry"
                    self._finish(task, res.model_id, state, started, "ok", res.note)
                    return res
            kind = "deadline" if self._clock() >= deadline else "exhausted"
            self._finish(task, None, state, started, kind)
            raise AllModelsUnavailable(kind, "All eligible models failed or were out of time.", state.attempts)

    async def _try_model(self, spec, is_last, task, messages, prof, max_tokens, idempotent, state, deadline):
        excluded: set[str] = set()
        transient_retry_used = False
        mt = min(max_tokens or prof.max_tokens, spec.max_output_tokens)
        use_json = bool(prof.json and spec.supports_json is True)
        while True:
            if state.n >= self.max_attempts or self._clock() >= deadline:
                return None
            lease = self.creds.select(exclude=excluded)
            if lease is None:
                raise AllModelsUnavailable("no_key", "No usable NVIDIA API key is available.")
            timeout = min(spec.timeout_s, self.request_timeout_cap_s, deadline - self._clock())
            if timeout <= 0.5:
                return None
            state.n += 1
            t0 = self._clock()
            try:
                result = await self.client.chat(model=spec.id, messages=messages, api_key=lease.secret,
                                                max_tokens=mt, temperature=prof.temperature,
                                                timeout=timeout, json_mode=use_json)
            except AIError as e:
                secs = self._clock() - t0
                state.attempts.append(Attempt(spec.id, lease.label, e.kind.value, secs))
                action = await self._handle_error(e, spec, lease, is_last, idempotent, excluded,
                                                  transient_retry_used, deadline)
                if action == "retry_same_after_wait":
                    transient_retry_used = True
                    continue
                if action == "retry":
                    continue
                return None
            secs = self._clock() - t0
            state.attempts.append(Attempt(spec.id, lease.label, "ok", secs))
            self.health.record_success(spec.id, secs)
            self.creds.report_success(lease.label)
            return RouteResult(text=result.text, model_id=spec.id, key_label=lease.label, task=task,
                               usage=getattr(result, "usage", {}) or {})

    async def _handle_error(self, e: AIError, spec, lease, is_last, idempotent, excluded,
                            transient_retry_used, deadline) -> str:
        kind = e.kind
        if kind == AIErrorKind.AUTH:
            # A rejected key will not start working; never retry it. Try another key if one exists.
            self.creds.report_auth_failure(lease.label)
            excluded.add(lease.label)
            log_event(log, "auth_failure", level=logging.WARNING, key=lease.label, model=spec.id)
            if not self.creds.has_usable(excluded):
                raise AllModelsUnavailable("auth", "NVIDIA rejected the API key (authentication/authorization failure).")
            return "retry"
        if kind == AIErrorKind.RATE_LIMIT:
            if self.creds.can_rotate_on_rate_limit:
                self.creds.report_rate_limit(lease.label, e.retry_after)
                excluded.add(lease.label)
                if self.creds.has_usable(excluded):
                    return "retry"                      # per-key quota: another key is a legitimate retry
            self.health.record_failure(spec.id, kind, e.retry_after)
            if is_last and e.retry_after and not transient_retry_used:
                wait = e.retry_after
                if wait <= (deadline - self._clock()) * 0.4:
                    await self._sleep(wait)
                    return "retry_same_after_wait"
            return "next_model"
        if kind in (AIErrorKind.BAD_REQUEST, AIErrorKind.NOT_FOUND):
            self.health.record_failure(spec.id, kind)   # permanent for this model: no retries
            return "next_model"
        # transient failures
        self.health.record_failure(spec.id, kind)
        if not idempotent and kind in AMBIGUOUS_KINDS:
            raise AmbiguousFailure(f"{kind.value} on {spec.id}; not retried because the request is not repeatable.")
        if is_last and not transient_retry_used and kind in TRANSIENT_KINDS:
            remaining = deadline - self._clock()
            wait = min(self.backoff_max, self.backoff_base * (1 + self._rng()))
            if wait < remaining * 0.4:
                await self._sleep(wait)
                return "retry_same_after_wait"
        return "next_model"                              # prefer switching over waiting

    # ------------------------------------------------------------ bookkeeping
    def _finish(self, task, model_id, state: _State, started, outcome, note=""):
        duration = self._clock() - started
        for a in state.attempts:
            s = self._stats[a.model]
            s["requests"] += 1
            if a.outcome == "ok":
                s["ok"] += 1
                s["latency_sum"] += a.seconds
            else:
                s["fail"] += 1
        self._history.append({
            "time": self._wall(), "task": task, "model": model_id, "outcome": outcome,
            "attempts": [(a.model, a.outcome) for a in state.attempts],
            "duration_s": round(duration, 2), "note": note,
        })
        log_event(log, "ai_request", task=task, model=model_id, outcome=outcome,
                  duration_ms=int(duration * 1000), attempts=len(state.attempts),
                  failover_reason=note or None,
                  failure_kinds=[a.outcome for a in state.attempts if a.outcome != "ok"])

    def history(self, n: int = 10) -> list[dict]:
        return list(self._history)[-n:]

    def stats(self) -> dict:
        per_model = {}
        for mid, s in self._stats.items():
            per_model[mid] = {**s, "avg_latency_s": round(s["latency_sum"] / s["ok"], 2) if s["ok"] else None,
                              "success_rate": round(s["ok"] / s["requests"], 2) if s["requests"] else None}
        return {"total_requests": self.total_requests, "failovers": self.failovers, "per_model": per_model}
