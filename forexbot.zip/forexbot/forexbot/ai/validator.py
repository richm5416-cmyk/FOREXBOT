"""Strict validation of AI trading analysis. Anything doubtful becomes NO_TRADE."""
from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass, field

SIGNALS = {"BUY", "SELL", "NO_TRADE"}
BIAS = {"bullish", "bearish", "neutral"}


class AnalysisValidationError(Exception):
    def __init__(self, reasons: list[str]):
        super().__init__("; ".join(reasons))
        self.reasons = reasons


@dataclass
class ValidatedSignal:
    pair: str
    timeframe: str
    bias: str
    signal: str
    entry: float | None
    stop_loss: float | None
    take_profits: list[float]
    risk_reward: float | None
    entry_conditions: list[str]
    supporting: list[str]
    contradicting: list[str]
    invalidation: list[str]
    model_id: str
    analysis_time: float
    data_time: float
    data_quality: str
    notes: list[str] = field(default_factory=list)


def extract_json(text: str) -> dict:
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t, flags=re.I).strip()
    start, end = t.find("{"), t.rfind("}")
    if start == -1 or end <= start:
        raise AnalysisValidationError(["Reply did not contain a JSON object."])
    try:
        obj = json.loads(t[start:end + 1])
    except ValueError:
        raise AnalysisValidationError(["Reply contained invalid JSON."])
    if not isinstance(obj, dict):
        raise AnalysisValidationError(["Reply JSON was not an object."])
    return obj


def _num(v, name: str, errors: list[str]) -> float | None:
    if isinstance(v, bool) or v is None:
        errors.append(f"{name} is missing or not a number.")
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        errors.append(f"{name} is not a number.")
        return None
    if not math.isfinite(f) or f <= 0:
        errors.append(f"{name} is not a valid price.")
        return None
    return f


def _strs(v) -> list[str]:
    if isinstance(v, str):
        return [v] if v.strip() else []
    if isinstance(v, list):
        return [str(x) for x in v if str(x).strip()]
    return []


def validate_analysis(payload: dict, *, pair: str, timeframe: str, last_close: float, atr: float,
                      data_time: float, analysis_time: float, model_id: str, min_rr: float) -> ValidatedSignal:
    errors: list[str] = []
    notes: list[str] = []
    signal = str(payload.get("signal", "")).strip().upper().replace(" ", "_")
    bias = str(payload.get("market_bias", payload.get("bias", ""))).strip().lower()
    if signal not in SIGNALS:
        errors.append("signal must be BUY, SELL or NO_TRADE.")
    if bias not in BIAS:
        errors.append("market_bias must be bullish, bearish or neutral.")
    claimed_pair = str(payload.get("pair", "")).upper().replace("/", "")
    if claimed_pair and claimed_pair != pair.replace("/", ""):
        errors.append(f"Reply was about {payload.get('pair')}, not {pair}.")
    dq = str(payload.get("data_quality", "ok")).strip().lower()
    if dq in ("poor", "stale", "bad", "insufficient", "missing"):
        errors.append(f"Model reported data quality '{dq}'.")

    supporting = _strs(payload.get("supporting_evidence"))
    contradicting = _strs(payload.get("contradicting_evidence"))
    invalidation = _strs(payload.get("invalidation_conditions", payload.get("invalidation")))
    conditions = _strs(payload.get("entry_conditions"))

    entry = stop = None
    tps: list[float] = []
    rr = None
    if not errors and signal in ("BUY", "SELL"):
        entry = _num(payload.get("entry"), "entry", errors)
        stop = _num(payload.get("stop_loss"), "stop_loss", errors)
        raw_tps = payload.get("take_profit", payload.get("take_profits"))
        raw_tps = raw_tps if isinstance(raw_tps, list) else [raw_tps]
        for i, t in enumerate(raw_tps):
            v = _num(t, f"take_profit[{i + 1}]", errors)
            if v is not None:
                tps.append(v)
        if not tps and not any("take_profit" in e for e in errors):
            errors.append("take_profit is missing: at least one target is required.")
        if not supporting:
            errors.append("No supporting evidence was given.")
        if not invalidation:
            errors.append("No invalidation condition was given.")
        if (signal == "BUY" and bias == "bearish") or (signal == "SELL" and bias == "bullish"):
            errors.append(f"Contradiction: {signal} signal with {bias} bias.")
        if not errors:
            if signal == "BUY" and not (stop < entry < min(tps)):
                errors.append("For BUY the order must be stop_loss < entry < take_profit.")
            if signal == "SELL" and not (stop > entry > max(tps)):
                errors.append("For SELL the order must be take_profit < entry < stop_loss.")
        if not errors:
            risk = abs(entry - stop)
            if not 0.3 <= risk / atr <= 4.0:
                errors.append("Stop-loss distance is unreasonable compared with current volatility (ATR).")
            if abs(entry - last_close) > atr:
                errors.append("Entry is too far from the current price (more than 1 ATR).")
            first_tp = min(tps) if signal == "BUY" else max(tps)     # nearest target
            rr = abs(first_tp - entry) / risk if risk else 0.0
            if rr < min_rr:
                errors.append(f"Risk-to-reward {rr:.2f} is below the minimum {min_rr}.")
            claimed = payload.get("risk_reward", payload.get("risk_to_reward"))
            try:
                if claimed is not None and abs(float(claimed) - rr) > 0.25 * max(rr, 0.1):
                    notes.append("Model's stated risk-reward differed from the computed value; computed value used.")
            except (TypeError, ValueError):
                pass
    if errors:
        raise AnalysisValidationError(errors)
    return ValidatedSignal(
        pair=pair, timeframe=timeframe, bias=bias, signal=signal, entry=entry, stop_loss=stop,
        take_profits=sorted(tps) if signal == "BUY" else sorted(tps, reverse=True),
        risk_reward=None if rr is None else round(rr, 2), entry_conditions=conditions, supporting=supporting,
        contradicting=contradicting, invalidation=invalidation, model_id=model_id,
        analysis_time=analysis_time, data_time=data_time, data_quality="ok", notes=notes)
