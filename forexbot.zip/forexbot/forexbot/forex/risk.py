"""Deterministic trading safeguards. Independent of which AI model answered."""
from __future__ import annotations

import json
import math
import os
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from .indicators import pip_size


def pip_value_per_lot_usd(pair: str, price: float) -> float | None:
    """USD value of one pip for 1 standard lot (100,000 units), for a USD account.
    Only USD-quoted and USD-based pairs are supported; crosses need a conversion rate (not implemented)."""
    base, quote = pair.upper().split("/")
    if quote == "USD":
        return 100_000 * pip_size(pair)
    if base == "USD" and price > 0:
        return 100_000 * pip_size(pair) / price
    return None


@dataclass
class RiskDecision:
    approved: bool
    reasons: list[str] = field(default_factory=list)
    lots: float = 0.0
    risk_amount: float = 0.0


class RiskManager:
    def __init__(self, settings, clock=time.time):
        self.s = settings
        self._clock = clock
        self._path = Path(settings.state_file) if settings.state_file else None
        self.state = {"signals": [], "positions": [], "day": "", "pnl_today": 0.0}
        self._load()

    # ---------------------------------------------------------- persistence
    def _load(self):
        if self._path and self._path.exists():
            try:
                data = json.loads(self._path.read_text())
                if isinstance(data, dict):
                    self.state.update({k: data[k] for k in self.state if k in data})
            except (ValueError, OSError):
                pass            # corrupt state: start clean (fail-safe for duplicates is the short window)

    def _save(self):
        if not self._path:
            return
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self._path.parent)
            with os.fdopen(fd, "w") as f:
                json.dump(self.state, f)
            os.replace(tmp, self._path)
        except OSError:
            pass

    def _today(self) -> str:
        return datetime.fromtimestamp(self._clock(), timezone.utc).strftime("%Y-%m-%d")

    def _roll_day(self):
        if self.state["day"] != self._today():
            self.state["day"], self.state["pnl_today"] = self._today(), 0.0

    # --------------------------------------------------------------- sizing
    def position_size(self, pair: str, entry: float, stop: float) -> tuple[float, float, str | None]:
        pv = pip_value_per_lot_usd(pair, entry)
        if pv is None:
            return 0.0, 0.0, f"Position sizing for {pair} is not supported (needs a currency conversion)."
        stop_pips = round(abs(entry - stop) / pip_size(pair), 4)     # avoid float noise (19.9999 pips)
        if stop_pips <= 0:
            return 0.0, 0.0, "Stop-loss distance is zero."
        risk_amount = self.s.account_balance * self.s.risk_per_trade_pct / 100
        lots = math.floor(round(risk_amount / (stop_pips * pv) * 100, 6)) / 100      # round DOWN to 0.01 lot
        if lots < 0.01:
            return 0.0, risk_amount, "Account is too small to risk this trade at the configured risk % (below 0.01 lot)."
        return lots, risk_amount, None

    # ------------------------------------------------------------- the gate
    def evaluate(self, sig, snapshot, now: float | None = None) -> RiskDecision:
        now = self._clock() if now is None else now
        self._roll_day()
        reasons: list[str] = []
        if sig.signal not in ("BUY", "SELL"):
            return RiskDecision(False, ["No trade signal to authorize."])
        if self.s.trading_mode != "paper":
            reasons.append("Live trading is not enabled. This bot only records paper trades.")
        if snapshot.is_stale(now):
            reasons.append("Market data is stale.")
        if snapshot.spread_pips is not None and snapshot.spread_pips > self.s.max_spread_pips:
            reasons.append(f"Spread {snapshot.spread_pips:.1f} pips is above the {self.s.max_spread_pips} pip limit.")
        if sig.risk_reward is None or sig.risk_reward < self.s.min_risk_reward:
            reasons.append("Risk-to-reward is below the configured minimum.")
        if self.state["pnl_today"] <= -self.s.account_balance * self.s.max_daily_loss_pct / 100:
            reasons.append("Maximum daily loss reached. No new trades today.")
        if len(self.state["positions"]) >= self.s.max_open_positions:
            reasons.append("Maximum number of open positions reached.")
        if any(p["pair"] == sig.pair for p in self.state["positions"]):
            reasons.append(f"A paper position in {sig.pair} is already open.")
        window = self.s.duplicate_window_minutes * 60
        if any(x["pair"] == sig.pair and x["dir"] == sig.signal and now - x["ts"] < window
               for x in self.state["signals"]):
            reasons.append("Duplicate signal: the same pair and direction was already issued recently.")
        lots, risk_amount, err = self.position_size(sig.pair, sig.entry, sig.stop_loss)
        if err:
            reasons.append(err)
        if reasons:
            return RiskDecision(False, reasons, 0.0, risk_amount)
        return RiskDecision(True, [], lots, risk_amount)

    # -------------------------------------------------------------- records
    def register_signal(self, sig, now: float | None = None):
        now = self._clock() if now is None else now
        cutoff = now - 7 * 86400
        self.state["signals"] = [x for x in self.state["signals"] if x["ts"] > cutoff]
        self.state["signals"].append({"pair": sig.pair, "dir": sig.signal, "ts": now})
        self._save()

    def open_paper_position(self, sig, lots: float):
        self.state["positions"].append({"id": f"{sig.pair}-{int(self._clock())}", "pair": sig.pair,
                                        "dir": sig.signal, "entry": sig.entry, "sl": sig.stop_loss,
                                        "tp": sig.take_profits, "lots": lots, "opened": self._clock()})
        self._save()

    def close_position(self, position_id: str, pnl: float) -> bool:
        self._roll_day()
        before = len(self.state["positions"])
        self.state["positions"] = [p for p in self.state["positions"] if p["id"] != position_id]
        if len(self.state["positions"]) == before:
            return False
        self.state["pnl_today"] += pnl
        self._save()
        return True

    def record_result(self, pnl: float):
        self._roll_day()
        self.state["pnl_today"] += pnl
        self._save()
