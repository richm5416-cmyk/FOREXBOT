"""Chart rendering for the /chart command. Pure logic, no Discord code.

Candles currently come from Yahoo Finance (via yfinance). To switch to your
TwelveDataProvider later, only fetch_candles() needs to change.
"""
from __future__ import annotations

import asyncio
import io
import logging
from dataclasses import dataclass
from typing import Optional

import matplotlib

matplotlib.use("Agg")  # headless rendering; must be set before mplfinance is imported

import mplfinance as mpf  # noqa: E402
import pandas as pd  # noqa: E402
import yfinance as yf  # noqa: E402

log = logging.getLogger("forexbot.charts")

MAX_CANDLES = 120

CURRENCIES = {
    "USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD",
    "SEK", "NOK", "DKK", "PLN", "CZK", "HUF", "TRY", "ZAR",
    "MXN", "SGD", "HKD", "CNY", "INR", "THB", "ILS", "KRW",
}

# bot timeframe -> (yfinance interval, yfinance period, resample rule or None)
TIMEFRAMES = {
    "M5": ("5m", "5d", None),
    "M15": ("15m", "5d", None),
    "M30": ("30m", "5d", None),
    "H1": ("1h", "1mo", None),
    "H4": ("1h", "3mo", "4h"),  # Yahoo has no 4h candles, so build them from 1h
    "D1": ("1d", "6mo", None),
    "W1": ("1wk", "2y", None),
}


class ChartError(Exception):
    """Raised with a message that is safe to show directly to the user."""


@dataclass
class ChartResult:
    png: bytes
    pair: str          # e.g. "EURUSD"
    timeframe: str     # e.g. "H4"
    last_close: float
    decimals: int
    tradingview_url: str


_fetch_lock: Optional[asyncio.Lock] = None


def parse_pair(raw: str) -> str:
    """'eur/usd', 'EUR-USD', 'eurusd' -> 'EURUSD'."""
    cleaned = "".join(ch for ch in raw.upper() if ch.isalpha())
    if len(cleaned) != 6:
        raise ChartError("That doesn't look like a currency pair. Try `EUR/USD` or `GBPJPY`.")
    base, quote = cleaned[:3], cleaned[3:]
    if base == quote or base not in CURRENCIES or quote not in CURRENCIES:
        raise ChartError(f"I don't support the pair `{base}/{quote}`.")
    return cleaned


def parse_timeframe(raw: str) -> str:
    tf = raw.strip().upper()
    if tf not in TIMEFRAMES:
        raise ChartError(f"Timeframe must be one of: {', '.join(TIMEFRAMES)}.")
    return tf


def _fetch_candles(pair: str, tf: str) -> pd.DataFrame:
    interval, period, resample = TIMEFRAMES[tf]
    df = yf.download(
        f"{pair}=X",
        interval=interval,
        period=period,
        progress=False,
        auto_adjust=False,
    )
    if df is None or df.empty:
        raise ChartError("No data came back. The market may be closed, or this pair isn't available.")

    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df[["Open", "High", "Low", "Close"]].dropna()

    if df.index.tz is not None:
        df.index = df.index.tz_convert("UTC").tz_localize(None)

    if resample:
        df = (
            df.resample(resample)
            .agg({"Open": "first", "High": "max", "Low": "min", "Close": "last"})
            .dropna()
        )
    if len(df) < 5:
        raise ChartError("Not enough candles came back to draw a chart.")
    return df.tail(MAX_CANDLES)


def _render(df: pd.DataFrame, pair: str, tf: str) -> bytes:
    buf = io.BytesIO()
    mavs = tuple(m for m in (20, 50) if m < len(df))
    kwargs = dict(
        type="candle",
        style="nightclouds",
        title=f"{pair[:3]}/{pair[3:]} - {tf}",
        ylabel="Price",
        figsize=(11, 6),
        savefig=dict(fname=buf, format="png", dpi=110, bbox_inches="tight"),
    )
    if mavs:
        kwargs["mav"] = mavs
    mpf.plot(df, **kwargs)
    return buf.getvalue()


async def build_chart(raw_pair: str, raw_timeframe: str) -> ChartResult:
    """Validate input, fetch candles, render a PNG. Raises ChartError with a user-safe message."""
    global _fetch_lock
    pair = parse_pair(raw_pair)
    tf = parse_timeframe(raw_timeframe)
    if _fetch_lock is None:
        _fetch_lock = asyncio.Lock()  # yfinance misbehaves with concurrent downloads

    try:
        async with _fetch_lock:
            df = await asyncio.to_thread(_fetch_candles, pair, tf)
        png = await asyncio.to_thread(_render, df, pair, tf)
    except ChartError:
        raise
    except Exception as exc:  # noqa: BLE001 - never leak internals to Discord
        log.error("chart failed for %s %s: %s", pair, tf, type(exc).__name__)
        raise ChartError("I couldn't build that chart right now. Please try again shortly.") from exc

    decimals = 3 if "JPY" in (pair[:3], pair[3:]) else 5
    return ChartResult(
        png=png,
        pair=pair,
        timeframe=tf,
        last_close=float(df["Close"].iloc[-1]),
        decimals=decimals,
        tradingview_url=f"https://www.tradingview.com/chart/?symbol=FX:{pair}",
    )
