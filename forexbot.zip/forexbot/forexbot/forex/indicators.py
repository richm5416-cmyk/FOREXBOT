"""Deterministic market maths. No AI involved."""
from __future__ import annotations

from dataclasses import dataclass


def pip_size(pair: str) -> float:
    return 0.01 if pair.upper().replace("/", "").endswith("JPY") else 0.0001


def ema(values: list[float], period: int) -> list[float]:
    if len(values) < period:
        return []
    k = 2 / (period + 1)
    out = [sum(values[:period]) / period]
    for v in values[period:]:
        out.append(v * k + out[-1] * (1 - k))
    return out


def rsi(closes: list[float], period: int = 14) -> float | None:
    if len(closes) <= period:
        return None
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0)
        losses += max(-d, 0)
    ag, al = gains / period, losses / period
    for i in range(period + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        ag = (ag * (period - 1) + max(d, 0)) / period
        al = (al * (period - 1) + max(-d, 0)) / period
    if al == 0:
        return 100.0
    return 100 - 100 / (1 + ag / al)


def atr(highs: list[float], lows: list[float], closes: list[float], period: int = 14) -> float | None:
    if len(closes) <= period:
        return None
    trs = [max(highs[i] - lows[i], abs(highs[i] - closes[i - 1]), abs(lows[i] - closes[i - 1]))
           for i in range(1, len(closes))]
    a = sum(trs[:period]) / period
    for tr in trs[period:]:
        a = (a * (period - 1) + tr) / period
    return a


def swing_levels(highs: list[float], lows: list[float], lookback: int = 3, max_levels: int = 3):
    """Simple support/resistance from recent swing highs and lows."""
    res, sup = [], []
    for i in range(lookback, len(highs) - lookback):
        if highs[i] == max(highs[i - lookback:i + lookback + 1]):
            res.append(highs[i])
        if lows[i] == min(lows[i - lookback:i + lookback + 1]):
            sup.append(lows[i])
    return sorted(set(sup))[-max_levels:], sorted(set(res))[-max_levels:]


@dataclass
class IndicatorSet:
    last_close: float
    ema20: float
    ema50: float
    rsi14: float
    atr14: float
    trend: str                 # bullish / bearish / neutral
    support: list[float]
    resistance: list[float]
    pip: float


def compute(pair: str, opens, highs, lows, closes) -> IndicatorSet | None:
    e20, e50 = ema(closes, 20), ema(closes, 50)
    r, a = rsi(closes), atr(highs, lows, closes)
    if not e20 or not e50 or r is None or a is None:
        return None
    slope = e20[-1] - e20[-6] if len(e20) > 6 else 0.0
    if closes[-1] > e20[-1] > e50[-1] and slope > 0:
        trend = "bullish"
    elif closes[-1] < e20[-1] < e50[-1] and slope < 0:
        trend = "bearish"
    else:
        trend = "neutral"
    sup, res = swing_levels(highs[-80:], lows[-80:])
    return IndicatorSet(closes[-1], e20[-1], e50[-1], r, a, trend, sup, res, pip_size(pair))
