"""Market-data providers. Every dataset carries its source and timestamp."""
from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone

import aiohttp

log = logging.getLogger("forexbot.market_data")

INTERVAL_SECONDS = {"1min": 60, "5min": 300, "15min": 900, "30min": 1800, "1h": 3600, "4h": 14400, "1day": 86400}
ALIASES = {"m1": "1min", "m5": "5min", "m15": "15min", "m30": "30min", "h1": "1h", "h4": "4h", "d1": "1day",
           "1d": "1day", "d": "1day", "1m": "1min", "5m": "5min", "15m": "15min", "30m": "30min", "60min": "1h"}
HIGHER_TIMEFRAME = {"5min": "1h", "15min": "1h", "30min": "4h", "1h": "4h", "4h": "1day"}
STALE_INTERVALS = 2          # data older than 2 candle-lengths is stale

# Backup source (Yahoo Finance via yfinance): bot timeframe -> (yfinance interval, period, resample rule or None)
YAHOO_INTERVALS = {
    "1min": ("1m", "5d", None),
    "5min": ("5m", "5d", None),
    "15min": ("15m", "5d", None),
    "30min": ("30m", "1mo", None),
    "1h": ("1h", "1mo", None),
    "4h": ("1h", "3mo", "4h"),      # Yahoo has no 4h candles, so they are built from 1h
    "1day": ("1d", "1y", None),
}


class MarketDataError(Exception):
    pass


def normalize_timeframe(tf: str) -> str:
    t = tf.strip().lower()
    t = ALIASES.get(t, t)
    if t not in INTERVAL_SECONDS:
        raise MarketDataError(f"Unsupported timeframe '{tf}'. Use one of: M5, M15, M30, H1, H4, D1.")
    return t


def normalize_pair(pair: str) -> str:
    p = pair.strip().upper().replace("-", "/").replace("_", "/")
    if re.fullmatch(r"[A-Z]{6}", p):
        p = p[:3] + "/" + p[3:]
    if not re.fullmatch(r"[A-Z]{3}/[A-Z]{3}", p):
        raise MarketDataError(f"'{pair}' is not a valid currency pair (example: EUR/USD).")
    return p


@dataclass
class Candle:
    start: float            # epoch seconds (UTC) at the candle's open
    open: float
    high: float
    low: float
    close: float


@dataclass
class MarketSnapshot:
    pair: str
    timeframe: str
    candles: list[Candle]
    source: str
    fetched_at: float                    # epoch seconds
    spread_pips: float | None = None     # None = unknown (spread check cannot be done)

    @property
    def interval(self) -> int:
        return INTERVAL_SECONDS[self.timeframe]

    @property
    def last_candle_start(self) -> float:
        return self.candles[-1].start

    def age_seconds(self, now: float | None = None) -> float:
        """How long ago the latest candle should have started updating (0 = perfectly fresh)."""
        now = time.time() if now is None else now
        return max(0.0, now - self.last_candle_start - self.interval)

    def is_stale(self, now: float | None = None) -> bool:
        now = time.time() if now is None else now
        return (now - self.last_candle_start) > STALE_INTERVALS * self.interval


def parse_twelvedata(payload: dict, pair: str, timeframe: str, fetched_at: float) -> MarketSnapshot:
    if not isinstance(payload, dict):
        raise MarketDataError("Market data response was not valid.")
    if payload.get("status") == "error" or "values" not in payload:
        raise MarketDataError(f"Market data provider error: {str(payload.get('message', 'no data'))[:120]}")
    candles = []
    for row in payload["values"]:
        try:
            dt = datetime.strptime(row["datetime"][:19].replace("T", " "),
                                   "%Y-%m-%d %H:%M:%S" if len(row["datetime"]) > 10 else "%Y-%m-%d")
            candles.append(Candle(dt.replace(tzinfo=timezone.utc).timestamp(), float(row["open"]),
                                  float(row["high"]), float(row["low"]), float(row["close"])))
        except (KeyError, ValueError, TypeError):
            raise MarketDataError("Market data contained a malformed candle.")
    candles.sort(key=lambda c: c.start)
    if not candles:
        raise MarketDataError("Market data provider returned no candles.")
    return MarketSnapshot(pair, timeframe, candles, "twelvedata", fetched_at)


def _fetch_yahoo(pair: str, timeframe: str, count: int) -> list[Candle]:
    """Blocking call (run it in a thread). Returns candles oldest-first, open times in UTC."""
    try:
        import yfinance as yf
    except ImportError:
        raise MarketDataError("Backup data source needs yfinance (pip install yfinance).")
    interval, period, resample = YAHOO_INTERVALS[timeframe]
    symbol = pair.replace("/", "") + "=X"
    try:
        df = yf.download(symbol, interval=interval, period=period, progress=False, auto_adjust=False)
    except Exception:  # noqa: BLE001 - yfinance raises many different things
        raise MarketDataError("Backup data source could not be reached.")
    if df is None or df.empty:
        raise MarketDataError("Backup data source returned no candles.")

    if getattr(df.columns, "nlevels", 1) > 1:          # newer yfinance returns two-level columns
        df.columns = df.columns.get_level_values(0)
    try:
        df = df[["Open", "High", "Low", "Close"]].dropna()
    except KeyError:
        raise MarketDataError("Backup data source returned an unexpected format.")
    if df.empty:
        raise MarketDataError("Backup data source returned no candles.")

    idx = df.index
    if interval == "1d":
        # Daily bars carry a local-midnight stamp; keep the calendar date and call it UTC midnight.
        idx = idx.tz_localize(None) if idx.tz is not None else idx
        idx = idx.tz_localize("UTC")
    else:
        idx = idx.tz_convert("UTC") if idx.tz is not None else idx.tz_localize("UTC")
    df.index = idx

    if resample:
        df = (df.resample(resample)
                .agg({"Open": "first", "High": "max", "Low": "min", "Close": "last"})
                .dropna())
    df = df.tail(count)
    if df.empty:
        raise MarketDataError("Backup data source returned no candles.")
    return [Candle(ts.timestamp(), float(r["Open"]), float(r["High"]), float(r["Low"]), float(r["Close"]))
            for ts, r in df.iterrows()]


class TwelveDataProvider:
    """Twelve Data time-series API. (Written from their public docs; not verified against the live API
    in the build environment - run `python main.py --check` with your key to confirm.)

    If Twelve Data fails for any reason (missing key, daily limit reached, outage) and fallback is on,
    candles are fetched from Yahoo Finance instead. The snapshot's `source` says which one was used."""
    URL = "https://api.twelvedata.com/time_series"

    def __init__(self, api_key: str, session: aiohttp.ClientSession | None = None, fallback: bool = True):
        self.api_key = api_key
        self._session = session
        self.fallback = fallback
        self._yahoo_lock = asyncio.Lock()      # yfinance misbehaves with concurrent downloads

    async def get_snapshot(self, pair: str, timeframe: str, count: int = 150) -> MarketSnapshot:
        try:
            return await self._get_twelvedata(pair, timeframe, count)
        except MarketDataError as primary_error:
            if not self.fallback:
                raise
            log.warning("Twelve Data failed (%s); trying Yahoo Finance", primary_error)
            try:
                return await self._get_yahoo(pair, timeframe, count)
            except MarketDataError as backup_error:
                raise MarketDataError(f"{primary_error} Backup source also failed: {backup_error}")

    async def _get_twelvedata(self, pair: str, timeframe: str, count: int) -> MarketSnapshot:
        if not self.api_key:
            raise MarketDataError("TWELVEDATA_API_KEY is not set, so no market data is available.")
        params = {"symbol": pair, "interval": timeframe, "outputsize": count,
                  "timezone": "UTC", "apikey": self.api_key}
        try:
            if self._session is None:
                self._session = aiohttp.ClientSession()
            async with self._session.get(self.URL, params=params, timeout=aiohttp.ClientTimeout(total=15)) as r:
                data = await r.json(content_type=None)
        except asyncio.TimeoutError:
            raise MarketDataError("Market data request timed out.")
        except (aiohttp.ClientError, ValueError, OSError):
            raise MarketDataError("Could not reach the market data provider.")
        return parse_twelvedata(data, pair, timeframe, time.time())

    async def _get_yahoo(self, pair: str, timeframe: str, count: int) -> MarketSnapshot:
        if timeframe not in YAHOO_INTERVALS:
            raise MarketDataError(f"Backup source does not support timeframe '{timeframe}'.")
        async with self._yahoo_lock:
            candles = await asyncio.to_thread(_fetch_yahoo, pair, timeframe, count)
        return MarketSnapshot(pair, timeframe, candles, "yahoo-finance", time.time())

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
