"""Forex analysis workflow: deterministic data -> AI interpretation -> strict validation -> risk gate."""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field

from ..ai.router import AIRouter
from ..ai.validator import AnalysisValidationError, ValidatedSignal, extract_json, validate_analysis
from ..errors import AllModelsUnavailable, AmbiguousFailure
from ..logging_config import log_event
from . import indicators
from .market_data import (HIGHER_TIMEFRAME, MarketDataError, MarketSnapshot, normalize_pair,
                          normalize_timeframe)
from .risk import RiskDecision, RiskManager

log = logging.getLogger("forexbot.analyzer")

SYSTEM_PROMPT = (
    "You are a forex analysis assistant. Use ONLY the market data in the user message. "
    "You have no live data, news or internet access, so never invent prices, news or events. "
    "If the data is insufficient or unclear, answer with signal NO_TRADE. "
    "Reply with ONE JSON object and nothing else, using exactly these keys: "
    '{"pair": str, "timeframe": str, "market_bias": "bullish|bearish|neutral", '
    '"signal": "BUY|SELL|NO_TRADE", "entry_conditions": [str], "entry": number|null, '
    '"stop_loss": number|null, "take_profit": [number], "risk_reward": number|null, '
    '"supporting_evidence": [str], "contradicting_evidence": [str], '
    '"invalidation_conditions": [str], "data_quality": "ok|poor"}. '
    "A BUY needs stop_loss < entry < take_profit. A SELL needs take_profit < entry < stop_loss. "
    "Prefer NO_TRADE unless the setup is clear."
)


@dataclass
class AnalysisResult:
    pair: str
    timeframe: str
    signal: str                          # BUY / SELL / NO_TRADE  (NO_TRADE is the default for any problem)
    reasons: list[str] = field(default_factory=list)
    validated: ValidatedSignal | None = None
    risk: RiskDecision | None = None
    model_id: str | None = None
    data_source: str | None = None
    data_time: float | None = None
    analysis_time: float = 0.0
    error_category: str | None = None    # data / ai / validation / None


def _no_trade(pair, tf, reasons, category, now, **kw) -> AnalysisResult:
    return AnalysisResult(pair=pair, timeframe=tf, signal="NO_TRADE", reasons=reasons,
                          error_category=category, analysis_time=now, **kw)


class ForexAnalyzer:
    def __init__(self, provider, router: AIRouter, risk: RiskManager, settings, clock=time.time):
        self.provider, self.router, self.risk, self.s, self._clock = provider, router, risk, settings, clock

    async def analyze(self, pair: str, timeframe: str = "1h") -> AnalysisResult:
        """Never raises. Any problem => NO_TRADE with an explicit reason."""
        now = self._clock()
        try:
            pair, tf = normalize_pair(pair), normalize_timeframe(timeframe)
        except MarketDataError as e:
            return _no_trade(pair, timeframe, [str(e)], "data", now)
        if pair not in self.s.supported_pairs:
            return _no_trade(pair, tf, [f"{pair} is not enabled. Supported: {', '.join(self.s.supported_pairs)}"], "data", now)

        try:
            snap = await self.provider.get_snapshot(pair, tf)
        except MarketDataError as e:
            return _no_trade(pair, tf, [f"Market data unavailable: {e}"], "data", now)
        except Exception:                                   # provider bugs must not crash the bot
            log.exception("market data provider crashed")
            return _no_trade(pair, tf, ["Market data unavailable (internal error)."], "data", now)

        meta = dict(data_source=snap.source, data_time=snap.last_candle_start)
        if len(snap.candles) < 60:
            return _no_trade(pair, tf, ["Not enough candles to analyze (need at least 60)."], "data", now, **meta)
        if snap.is_stale(now):
            return _no_trade(pair, tf, ["Market data is stale (the market may be closed). No analysis was run."],
                             "data", now, **meta)

        ind = indicators.compute(pair, *self._cols(snap))
        if ind is None:
            return _no_trade(pair, tf, ["Could not compute indicators from the data."], "data", now, **meta)

        htf_info, task = None, "technical_analysis"
        htf = HIGHER_TIMEFRAME.get(tf)
        if htf:
            try:
                hs = await self.provider.get_snapshot(pair, htf)
                hi = None if hs.is_stale(now) else indicators.compute(pair, *self._cols(hs))
                if hi:
                    htf_info = {"timeframe": htf, "trend": hi.trend, "ema20": round(hi.ema20, 5),
                                "ema50": round(hi.ema50, 5), "rsi14": round(hi.rsi14, 1)}
                    task = "multi_timeframe"
            except Exception:
                htf_info = None                              # optional context only

        messages = [{"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": json.dumps(self._payload(snap, ind, htf_info))}]
        try:
            routed = await self.router.complete(task, messages, idempotent=True)
        except (AllModelsUnavailable, AmbiguousFailure) as e:
            log_event(log, "analysis_ai_unavailable", pair=pair, kind=getattr(e, "kind", "ambiguous"))
            return _no_trade(pair, tf, ["AI models are unavailable right now. No signal was produced "
                                        "and no earlier analysis was reused."], "ai", now, **meta)
        try:
            sig = validate_analysis(extract_json(routed.text), pair=pair, timeframe=tf,
                                    last_close=ind.last_close, atr=ind.atr14, data_time=snap.last_candle_start,
                                    analysis_time=now, model_id=routed.model_id, min_rr=self.s.min_risk_reward)
        except AnalysisValidationError as e:
            log_event(log, "analysis_rejected", pair=pair, model=routed.model_id, reasons=e.reasons)
            return _no_trade(pair, tf, ["AI output rejected: " + r for r in e.reasons], "validation", now,
                             model_id=routed.model_id, **meta)

        if sig.signal == "NO_TRADE":
            return AnalysisResult(pair, tf, "NO_TRADE", ["The model found no clear setup."], sig, None,
                                  routed.model_id, analysis_time=now, **meta)
        decision = self.risk.evaluate(sig, snap, now)
        if decision.approved:
            self.risk.register_signal(sig, now)
            if self.s.auto_paper_trade:
                self.risk.open_paper_position(sig, decision.lots)
        return AnalysisResult(pair, tf, sig.signal, decision.reasons, sig, decision, routed.model_id,
                              analysis_time=now, **meta)

    @staticmethod
    def _cols(s: MarketSnapshot):
        c = s.candles
        return [x.open for x in c], [x.high for x in c], [x.low for x in c], [x.close for x in c]

    @staticmethod
    def _payload(s: MarketSnapshot, ind, htf_info) -> dict:
        d = 3 if s.pair.endswith("JPY") else 5
        return {
            "pair": s.pair, "timeframe": s.timeframe, "data_source": s.source,
            "latest_candle_start_utc": int(s.last_candle_start),
            "last_close": round(ind.last_close, d), "pip_size": ind.pip,
            "indicators": {"ema20": round(ind.ema20, d), "ema50": round(ind.ema50, d),
                           "rsi14": round(ind.rsi14, 1), "atr14": round(ind.atr14, d),
                           "computed_trend": ind.trend},
            "support_levels": [round(x, d) for x in ind.support],
            "resistance_levels": [round(x, d) for x in ind.resistance],
            "higher_timeframe": htf_info or "unavailable",
            "recent_candles_ohlc": [[round(c.open, d), round(c.high, d), round(c.low, d), round(c.close, d)]
                                    for c in s.candles[-30:]],
            "spread_pips": s.spread_pips if s.spread_pips is not None else "unknown",
        }

    # ---------------------------------------------------------- text helpers
    async def quick_summary(self, pair: str, timeframe: str = "1h") -> str:
        try:
            pair, tf = normalize_pair(pair), normalize_timeframe(timeframe)
            snap = await self.provider.get_snapshot(pair, tf)
        except MarketDataError as e:
            return f"Can't summarize: {e}"
        if snap.is_stale() or len(snap.candles) < 60:
            return "Can't summarize: market data is stale or incomplete (the market may be closed)."
        ind = indicators.compute(pair, *self._cols(snap))
        if ind is None:
            return "Can't summarize: not enough data for indicators."
        msgs = [{"role": "system", "content": "Write a 3-4 sentence neutral market summary using ONLY the data "
                 "provided. Do not give trade advice. Do not mention anything not in the data."},
                {"role": "user", "content": json.dumps(self._payload(snap, ind, None))}]
        try:
            return (await self.router.complete("quick_summary", msgs)).text
        except (AllModelsUnavailable, AmbiguousFailure):
            return "AI models are unavailable right now, so no summary was produced."
