"""Structured JSON logging with automatic secret redaction."""
from __future__ import annotations

import json
import logging
import re
import sys
import time

_PATTERNS = [
    re.compile(r"nvapi-[A-Za-z0-9_\-]{6,}"),
    re.compile(r"[MNO][A-Za-z0-9_\-]{23,27}\.[A-Za-z0-9_\-]{6}\.[A-Za-z0-9_\-]{25,40}"),
    re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._\-]{8,}"),
    re.compile(r"(?i)(apikey=)[^&\s\"']+"),
]
_secrets: set[str] = set()


def register_secret(secret: str | None) -> None:
    """Tell the logger about a secret so it is always masked, whatever it looks like."""
    if secret and len(secret) >= 6:
        _secrets.add(secret)


def clear_secrets() -> None:
    _secrets.clear()


def redact(text: str) -> str:
    out = str(text)
    for s in sorted(_secrets, key=len, reverse=True):
        out = out.replace(s, "[REDACTED]")
    for p in _PATTERNS:
        if p.groups:
            out = p.sub(lambda m: m.group(1) + "[REDACTED]", out)
        else:
            out = p.sub("[REDACTED]", out)
    return out


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = redact(record.getMessage())
        record.args = ()
        return True


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        data = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)) + "Z",
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        fields = getattr(record, "fields", None)
        if fields:
            data.update(fields)
        if record.exc_info:
            data["error"] = self.formatException(record.exc_info).splitlines()[-1]
        return redact(json.dumps(data, default=str))


def setup_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    handler.addFilter(RedactingFilter())
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level.upper())
    logging.getLogger("discord").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)


def log_event(logger: logging.Logger, event: str, level: int = logging.INFO, **fields) -> None:
    logger.log(level, event, extra={"fields": fields})
