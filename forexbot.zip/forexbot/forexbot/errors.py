"""Shared exception types."""
from __future__ import annotations

from enum import Enum


class ConfigError(Exception):
    """Something is wrong with the settings or models.yaml."""


class AIErrorKind(str, Enum):
    RATE_LIMIT = "rate_limit"      # HTTP 429
    AUTH = "auth"                  # HTTP 401 / 403
    BAD_REQUEST = "bad_request"    # HTTP 400 / 422 (unsupported feature, bad input)
    NOT_FOUND = "not_found"        # HTTP 404 (model or endpoint missing)
    TIMEOUT = "timeout"            # our timeout, or HTTP 408
    SERVER = "server"              # HTTP 5xx
    NETWORK = "network"            # connection / DNS failure
    MALFORMED = "malformed"        # invalid JSON or unexpected schema
    EMPTY = "empty"                # model returned no text


# Failures that may succeed if tried again (or on another model).
TRANSIENT_KINDS = {
    AIErrorKind.TIMEOUT,
    AIErrorKind.SERVER,
    AIErrorKind.NETWORK,
    AIErrorKind.MALFORMED,
    AIErrorKind.EMPTY,
}

# Failures where the request MAY already have been processed by the provider.
AMBIGUOUS_KINDS = {
    AIErrorKind.TIMEOUT,
    AIErrorKind.SERVER,
    AIErrorKind.MALFORMED,
    AIErrorKind.EMPTY,
}


class AIError(Exception):
    """A classified failure from the NVIDIA API. Never contains an API key."""

    def __init__(self, kind: AIErrorKind, message: str = "", status: int | None = None,
                 retry_after: float | None = None):
        super().__init__(f"{kind.value}: {message}" if message else kind.value)
        self.kind = kind
        self.message = message
        self.status = status
        self.retry_after = retry_after


class AllModelsUnavailable(Exception):
    """No model could answer. `kind` is one of: no_model, no_key, auth, exhausted, deadline."""

    def __init__(self, kind: str, message: str, attempts: list | None = None):
        super().__init__(message)
        self.kind = kind
        self.message = message
        self.attempts = attempts or []


class AmbiguousFailure(Exception):
    """A non-repeatable request failed in a way that may have had an effect; we did not retry."""
